--
-- PostgreSQL database dump
--

\restrict nyTtfaANlX8dGoc1uB4vyXefRnsaDfiThdN4S8aNHFJpNKbU4h1a1hikgxRBjBh

-- Dumped from database version 15.17
-- Dumped by pg_dump version 15.17

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: handle_page_update(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.handle_page_update() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
  DECLARE
    current_dt timestamptz := clock_timestamp();
    proj_id uuid;
  BEGIN
    NEW.modified_at := current_dt;

    UPDATE file
       SET modified_at = current_dt
     WHERE id = OLD.file_id
 RETURNING project_id
      INTO STRICT proj_id;

    --- Update projects modified_at attribute when a
    --- page of that project is modified.
    UPDATE project
       SET modified_at = current_dt
     WHERE id = proj_id;

    RETURN NEW;
  END;
$$;


--
-- Name: raise_deletion_protection(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.raise_deletion_protection() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
  BEGIN
    RAISE EXCEPTION 'unable to proceed to delete row on "%"', TG_TABLE_NAME
          USING HINT = 'disable deletion protection with "SET rules.deletion_protection TO off"';
    RETURN NULL;
  END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: access_token; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.access_token (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    profile_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    name text NOT NULL,
    token text NOT NULL,
    perms text[],
    expires_at timestamp with time zone
);
ALTER TABLE ONLY public.access_token ALTER COLUMN name SET STORAGE EXTERNAL;
ALTER TABLE ONLY public.access_token ALTER COLUMN token SET STORAGE EXTERNAL;
ALTER TABLE ONLY public.access_token ALTER COLUMN perms SET STORAGE EXTERNAL;


--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_log (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name text NOT NULL,
    type text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    archived_at timestamp with time zone,
    profile_id uuid NOT NULL,
    props jsonb,
    ip_addr inet,
    tracked_at timestamp with time zone DEFAULT now(),
    source text,
    context jsonb
);
ALTER TABLE ONLY public.audit_log ALTER COLUMN name SET STORAGE EXTERNAL;
ALTER TABLE ONLY public.audit_log ALTER COLUMN type SET STORAGE EXTERNAL;
ALTER TABLE ONLY public.audit_log ALTER COLUMN props SET STORAGE EXTERNAL;
ALTER TABLE ONLY public.audit_log ALTER COLUMN source SET STORAGE EXTERNAL;
ALTER TABLE ONLY public.audit_log ALTER COLUMN context SET STORAGE EXTERNAL;


--
-- Name: comment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.comment (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    thread_id uuid NOT NULL,
    owner_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    modified_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    content text NOT NULL,
    mentions uuid[] DEFAULT '{}'::uuid[]
);
ALTER TABLE ONLY public.comment ALTER COLUMN content SET STORAGE EXTERNAL;


--
-- Name: comment_thread; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.comment_thread (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    file_id uuid NOT NULL,
    owner_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    modified_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    page_id uuid NOT NULL,
    participants jsonb NOT NULL,
    seqn integer DEFAULT 0 NOT NULL,
    "position" point NOT NULL,
    is_resolved boolean DEFAULT false NOT NULL,
    page_name text,
    frame_id uuid DEFAULT '00000000-0000-0000-0000-000000000000'::uuid,
    mentions uuid[] DEFAULT '{}'::uuid[]
);
ALTER TABLE ONLY public.comment_thread ALTER COLUMN participants SET STORAGE EXTERNAL;
ALTER TABLE ONLY public.comment_thread ALTER COLUMN page_name SET STORAGE EXTERNAL;


--
-- Name: comment_thread_status; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.comment_thread_status (
    thread_id uuid NOT NULL,
    profile_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    modified_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL
);


--
-- Name: file; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.file (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    project_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    modified_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    deleted_at timestamp with time zone,
    name text NOT NULL,
    is_shared boolean DEFAULT false NOT NULL,
    has_media_trimmed boolean DEFAULT false,
    revn bigint DEFAULT 0 NOT NULL,
    data bytea,
    ignore_sync_until timestamp with time zone,
    comment_thread_seqn integer DEFAULT 0,
    data_backend text,
    features text[],
    version integer,
    data_ref_id uuid,
    vern integer DEFAULT 0 NOT NULL
)
WITH (fillfactor='50');
ALTER TABLE ONLY public.file ALTER COLUMN name SET STORAGE EXTERNAL;
ALTER TABLE ONLY public.file ALTER COLUMN data SET STORAGE EXTERNAL;
ALTER TABLE ONLY public.file ALTER COLUMN data_backend SET STORAGE EXTERNAL;
ALTER TABLE ONLY public.file ALTER COLUMN features SET STORAGE EXTERNAL;


--
-- Name: file_change; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.file_change (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    file_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    session_id uuid,
    revn bigint DEFAULT 0 NOT NULL,
    data bytea,
    changes bytea,
    profile_id uuid,
    features text[],
    label text,
    data_backend text,
    data_ref_id uuid,
    version integer,
    created_by text DEFAULT 'system'::text NOT NULL,
    updated_at timestamp with time zone DEFAULT now(),
    deleted_at timestamp with time zone,
    migrations text[],
    locked_by uuid
);
ALTER TABLE ONLY public.file_change ALTER COLUMN data SET STORAGE EXTERNAL;
ALTER TABLE ONLY public.file_change ALTER COLUMN changes SET STORAGE EXTERNAL;
ALTER TABLE ONLY public.file_change ALTER COLUMN features SET STORAGE EXTERNAL;
ALTER TABLE ONLY public.file_change ALTER COLUMN label SET STORAGE EXTERNAL;


--
-- Name: COLUMN file_change.locked_by; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.file_change.locked_by IS 'Profile ID of user who has locked this version. Only the creator can lock/unlock their own versions. Locked versions cannot be deleted by others.';


--
-- Name: file_data; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.file_data (
    file_id uuid NOT NULL,
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    modified_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    type text NOT NULL,
    backend text,
    metadata jsonb,
    data bytea
)
PARTITION BY HASH (file_id);


--
-- Name: file_data_00; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.file_data_00 (
    file_id uuid NOT NULL,
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    modified_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    type text NOT NULL,
    backend text,
    metadata jsonb,
    data bytea
);


--
-- Name: file_data_01; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.file_data_01 (
    file_id uuid NOT NULL,
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    modified_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    type text NOT NULL,
    backend text,
    metadata jsonb,
    data bytea
);


--
-- Name: file_data_02; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.file_data_02 (
    file_id uuid NOT NULL,
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    modified_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    type text NOT NULL,
    backend text,
    metadata jsonb,
    data bytea
);


--
-- Name: file_data_03; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.file_data_03 (
    file_id uuid NOT NULL,
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    modified_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    type text NOT NULL,
    backend text,
    metadata jsonb,
    data bytea
);


--
-- Name: file_data_04; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.file_data_04 (
    file_id uuid NOT NULL,
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    modified_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    type text NOT NULL,
    backend text,
    metadata jsonb,
    data bytea
);


--
-- Name: file_data_05; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.file_data_05 (
    file_id uuid NOT NULL,
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    modified_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    type text NOT NULL,
    backend text,
    metadata jsonb,
    data bytea
);


--
-- Name: file_data_06; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.file_data_06 (
    file_id uuid NOT NULL,
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    modified_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    type text NOT NULL,
    backend text,
    metadata jsonb,
    data bytea
);


--
-- Name: file_data_07; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.file_data_07 (
    file_id uuid NOT NULL,
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    modified_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    type text NOT NULL,
    backend text,
    metadata jsonb,
    data bytea
);


--
-- Name: file_data_08; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.file_data_08 (
    file_id uuid NOT NULL,
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    modified_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    type text NOT NULL,
    backend text,
    metadata jsonb,
    data bytea
);


--
-- Name: file_data_09; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.file_data_09 (
    file_id uuid NOT NULL,
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    modified_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    type text NOT NULL,
    backend text,
    metadata jsonb,
    data bytea
);


--
-- Name: file_data_10; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.file_data_10 (
    file_id uuid NOT NULL,
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    modified_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    type text NOT NULL,
    backend text,
    metadata jsonb,
    data bytea
);


--
-- Name: file_data_11; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.file_data_11 (
    file_id uuid NOT NULL,
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    modified_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    type text NOT NULL,
    backend text,
    metadata jsonb,
    data bytea
);


--
-- Name: file_data_12; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.file_data_12 (
    file_id uuid NOT NULL,
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    modified_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    type text NOT NULL,
    backend text,
    metadata jsonb,
    data bytea
);


--
-- Name: file_data_13; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.file_data_13 (
    file_id uuid NOT NULL,
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    modified_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    type text NOT NULL,
    backend text,
    metadata jsonb,
    data bytea
);


--
-- Name: file_data_14; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.file_data_14 (
    file_id uuid NOT NULL,
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    modified_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    type text NOT NULL,
    backend text,
    metadata jsonb,
    data bytea
);


--
-- Name: file_data_15; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.file_data_15 (
    file_id uuid NOT NULL,
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    modified_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    type text NOT NULL,
    backend text,
    metadata jsonb,
    data bytea
);


--
-- Name: file_data_fragment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.file_data_fragment (
    id uuid NOT NULL,
    file_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    metadata jsonb,
    deleted_at timestamp with time zone,
    data bytea,
    data_backend text,
    data_ref_id uuid
);
ALTER TABLE ONLY public.file_data_fragment ALTER COLUMN metadata SET STORAGE EXTERNAL;


--
-- Name: file_library_rel; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.file_library_rel (
    file_id uuid NOT NULL,
    library_file_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    synced_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL
);


--
-- Name: TABLE file_library_rel; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.file_library_rel IS 'Relation between files and the shared library files they use (NM)';


--
-- Name: file_media_object; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.file_media_object (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    deleted_at timestamp with time zone,
    name text NOT NULL,
    width integer NOT NULL,
    height integer NOT NULL,
    mtype text NOT NULL,
    file_id uuid NOT NULL,
    is_local boolean DEFAULT false NOT NULL,
    media_id uuid NOT NULL,
    thumbnail_id uuid
);
ALTER TABLE ONLY public.file_media_object ALTER COLUMN name SET STORAGE EXTERNAL;
ALTER TABLE ONLY public.file_media_object ALTER COLUMN mtype SET STORAGE EXTERNAL;


--
-- Name: file_migration; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.file_migration (
    file_id uuid NOT NULL,
    name text NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL
);


--
-- Name: file_object_thumbnail; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.file_object_thumbnail (
    file_id uuid NOT NULL,
    object_id text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    data text,
    media_id uuid
);
ALTER TABLE ONLY public.file_object_thumbnail ALTER COLUMN data SET STORAGE EXTERNAL;


--
-- Name: file_profile_rel; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.file_profile_rel (
    file_id uuid NOT NULL,
    profile_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    modified_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    is_owner boolean DEFAULT false,
    is_admin boolean DEFAULT false,
    can_edit boolean DEFAULT false
);


--
-- Name: TABLE file_profile_rel; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.file_profile_rel IS 'Relation between files and profiles (NM)';


--
-- Name: file_tagged_object_thumbnail; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.file_tagged_object_thumbnail (
    file_id uuid NOT NULL,
    tag text DEFAULT 'frame'::text NOT NULL,
    object_id text NOT NULL,
    media_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone
);


--
-- Name: file_thumbnail; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.file_thumbnail (
    file_id uuid NOT NULL,
    revn bigint NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    data text,
    props jsonb,
    media_id uuid
);
ALTER TABLE ONLY public.file_thumbnail ALTER COLUMN data SET STORAGE EXTERNAL;
ALTER TABLE ONLY public.file_thumbnail ALTER COLUMN props SET STORAGE EXTERNAL;


--
-- Name: global_complaint_report; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.global_complaint_report (
    email text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    type text NOT NULL,
    content jsonb
);
ALTER TABLE ONLY public.global_complaint_report ALTER COLUMN type SET STORAGE EXTERNAL;
ALTER TABLE ONLY public.global_complaint_report ALTER COLUMN content SET STORAGE EXTERNAL;


--
-- Name: http_session; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.http_session (
    id text NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    profile_id uuid NOT NULL,
    user_agent text,
    updated_at timestamp with time zone
);
ALTER TABLE ONLY public.http_session ALTER COLUMN id SET STORAGE EXTERNAL;
ALTER TABLE ONLY public.http_session ALTER COLUMN user_agent SET STORAGE EXTERNAL;


--
-- Name: http_session_v2; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.http_session_v2 (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    modified_at timestamp with time zone DEFAULT now() NOT NULL,
    profile_id uuid,
    user_agent text,
    sso_provider_id uuid,
    sso_session_id text
);


--
-- Name: migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.migrations (
    module text,
    step text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: presence; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.presence (
    file_id uuid NOT NULL,
    profile_id uuid NOT NULL,
    session_id uuid NOT NULL,
    updated_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL
);


--
-- Name: profile; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.profile (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    modified_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    deleted_at timestamp with time zone,
    fullname text DEFAULT ''::text NOT NULL,
    email text NOT NULL,
    password text NOT NULL,
    lang text,
    theme text,
    is_demo boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT false NOT NULL,
    props jsonb,
    photo_id uuid,
    is_muted boolean DEFAULT false,
    auth_backend text,
    is_blocked boolean DEFAULT false,
    default_project_id uuid,
    default_team_id uuid
);
ALTER TABLE ONLY public.profile ALTER COLUMN fullname SET STORAGE EXTERNAL;
ALTER TABLE ONLY public.profile ALTER COLUMN email SET STORAGE EXTERNAL;
ALTER TABLE ONLY public.profile ALTER COLUMN password SET STORAGE EXTERNAL;
ALTER TABLE ONLY public.profile ALTER COLUMN lang SET STORAGE EXTERNAL;
ALTER TABLE ONLY public.profile ALTER COLUMN theme SET STORAGE EXTERNAL;
ALTER TABLE ONLY public.profile ALTER COLUMN props SET STORAGE EXTERNAL;
ALTER TABLE ONLY public.profile ALTER COLUMN auth_backend SET STORAGE EXTERNAL;


--
-- Name: profile_complaint_report; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.profile_complaint_report (
    profile_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    type text NOT NULL,
    content jsonb
);
ALTER TABLE ONLY public.profile_complaint_report ALTER COLUMN type SET STORAGE EXTERNAL;
ALTER TABLE ONLY public.profile_complaint_report ALTER COLUMN content SET STORAGE EXTERNAL;


--
-- Name: project; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    team_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    modified_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    deleted_at timestamp with time zone,
    is_default boolean DEFAULT false NOT NULL,
    name text NOT NULL
);
ALTER TABLE ONLY public.project ALTER COLUMN name SET STORAGE EXTERNAL;


--
-- Name: project_profile_rel; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_profile_rel (
    profile_id uuid NOT NULL,
    project_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    modified_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    is_owner boolean DEFAULT false,
    is_admin boolean DEFAULT false,
    can_edit boolean DEFAULT false,
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL
);


--
-- Name: scheduled_task; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.scheduled_task (
    id text NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    modified_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    cron_expr text NOT NULL
);
ALTER TABLE ONLY public.scheduled_task ALTER COLUMN id SET STORAGE EXTERNAL;
ALTER TABLE ONLY public.scheduled_task ALTER COLUMN cron_expr SET STORAGE EXTERNAL;


--
-- Name: scheduled_task_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.scheduled_task_history (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    task_id text NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    is_error boolean DEFAULT false NOT NULL,
    reason text
);


--
-- Name: server_error_report; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.server_error_report (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    content jsonb,
    version integer DEFAULT 1
);
ALTER TABLE ONLY public.server_error_report ALTER COLUMN content SET STORAGE EXTERNAL;


--
-- Name: server_prop; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.server_prop (
    id text NOT NULL,
    content jsonb,
    preload boolean DEFAULT false
);
ALTER TABLE ONLY public.server_prop ALTER COLUMN id SET STORAGE EXTERNAL;
ALTER TABLE ONLY public.server_prop ALTER COLUMN content SET STORAGE EXTERNAL;


--
-- Name: share_link; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.share_link (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    file_id uuid NOT NULL,
    owner_id uuid,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    pages uuid[],
    flags text[],
    who_comment text DEFAULT 'team'::text NOT NULL,
    who_inspect text DEFAULT 'team'::text NOT NULL
);


--
-- Name: sso_provider; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sso_provider (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    modified_at timestamp with time zone DEFAULT now() NOT NULL,
    is_enabled boolean DEFAULT true NOT NULL,
    type text NOT NULL,
    domain text NOT NULL,
    client_id text NOT NULL,
    client_secret text NOT NULL,
    base_uri text NOT NULL,
    token_uri text,
    auth_uri text,
    user_uri text,
    jwks_uri text,
    logout_uri text,
    roles_attr text,
    email_attr text,
    name_attr text,
    user_info_source text DEFAULT 'token'::text NOT NULL,
    scopes text[],
    roles text[],
    CONSTRAINT sso_provider_type_check CHECK ((type = 'oidc'::text)),
    CONSTRAINT sso_provider_user_info_source_check CHECK ((user_info_source = ANY (ARRAY['token'::text, 'userinfo'::text, 'auto'::text])))
);


--
-- Name: storage_object; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.storage_object (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    size bigint DEFAULT 0 NOT NULL,
    backend text NOT NULL,
    metadata jsonb,
    touched_at timestamp with time zone
)
WITH (fillfactor='60');
ALTER TABLE ONLY public.storage_object ALTER COLUMN backend SET STORAGE EXTERNAL;
ALTER TABLE ONLY public.storage_object ALTER COLUMN metadata SET STORAGE EXTERNAL;


--
-- Name: task; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.task (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    modified_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    scheduled_at timestamp with time zone NOT NULL,
    priority smallint DEFAULT 100,
    queue text NOT NULL,
    name text NOT NULL,
    props jsonb NOT NULL,
    error text,
    retry_num smallint DEFAULT 0 NOT NULL,
    max_retries smallint DEFAULT 3 NOT NULL,
    status text DEFAULT 'new'::text NOT NULL,
    label text
)
WITH (fillfactor='60');
ALTER TABLE ONLY public.task ALTER COLUMN queue SET STORAGE EXTERNAL;
ALTER TABLE ONLY public.task ALTER COLUMN name SET STORAGE EXTERNAL;
ALTER TABLE ONLY public.task ALTER COLUMN props SET STORAGE EXTERNAL;
ALTER TABLE ONLY public.task ALTER COLUMN error SET STORAGE EXTERNAL;
ALTER TABLE ONLY public.task ALTER COLUMN status SET STORAGE EXTERNAL;
ALTER TABLE ONLY public.task ALTER COLUMN label SET STORAGE EXTERNAL;


--
-- Name: team; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.team (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    modified_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    deleted_at timestamp with time zone,
    name text NOT NULL,
    is_default boolean DEFAULT false NOT NULL,
    photo_id uuid,
    features text[]
);
ALTER TABLE ONLY public.team ALTER COLUMN name SET STORAGE EXTERNAL;


--
-- Name: team_access_request; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.team_access_request (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    team_id uuid NOT NULL,
    requester_id uuid,
    valid_until timestamp with time zone NOT NULL,
    auto_join_until timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: team_font_variant; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.team_font_variant (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    team_id uuid NOT NULL,
    profile_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    modified_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    font_id uuid NOT NULL,
    font_family text NOT NULL,
    font_weight smallint NOT NULL,
    font_style text NOT NULL,
    otf_file_id uuid,
    ttf_file_id uuid,
    woff1_file_id uuid,
    woff2_file_id uuid
);
ALTER TABLE ONLY public.team_font_variant ALTER COLUMN font_family SET STORAGE EXTERNAL;
ALTER TABLE ONLY public.team_font_variant ALTER COLUMN font_style SET STORAGE EXTERNAL;


--
-- Name: team_invitation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.team_invitation (
    team_id uuid NOT NULL,
    email_to text NOT NULL,
    role text NOT NULL,
    valid_until timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    created_by uuid
);
ALTER TABLE ONLY public.team_invitation ALTER COLUMN email_to SET STORAGE EXTERNAL;
ALTER TABLE ONLY public.team_invitation ALTER COLUMN role SET STORAGE EXTERNAL;


--
-- Name: team_profile_rel; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.team_profile_rel (
    team_id uuid NOT NULL,
    profile_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    modified_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    is_admin boolean DEFAULT false,
    is_owner boolean DEFAULT false,
    can_edit boolean DEFAULT false,
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL
);


--
-- Name: TABLE team_profile_rel; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.team_profile_rel IS 'Relation between teams and profiles (NM)';


--
-- Name: team_project_profile_rel; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.team_project_profile_rel (
    team_id uuid NOT NULL,
    profile_id uuid NOT NULL,
    project_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    modified_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    is_pinned boolean DEFAULT false NOT NULL,
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL
);


--
-- Name: usage_quote; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.usage_quote (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    target text NOT NULL,
    quote bigint NOT NULL,
    profile_id uuid,
    project_id uuid,
    team_id uuid,
    file_id uuid
);
ALTER TABLE ONLY public.usage_quote ALTER COLUMN target SET STORAGE EXTERNAL;


--
-- Name: webhook; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.webhook (
    id uuid NOT NULL,
    team_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    uri text NOT NULL,
    mtype text NOT NULL,
    error_code text,
    error_count smallint DEFAULT 0,
    is_active boolean DEFAULT true,
    secret_key text,
    profile_id uuid
);
ALTER TABLE ONLY public.webhook ALTER COLUMN uri SET STORAGE EXTERNAL;
ALTER TABLE ONLY public.webhook ALTER COLUMN mtype SET STORAGE EXTERNAL;
ALTER TABLE ONLY public.webhook ALTER COLUMN error_code SET STORAGE EXTERNAL;
ALTER TABLE ONLY public.webhook ALTER COLUMN secret_key SET STORAGE EXTERNAL;


--
-- Name: webhook_delivery; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.webhook_delivery (
    webhook_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    error_code text,
    req_data jsonb,
    rsp_data jsonb
);
ALTER TABLE ONLY public.webhook_delivery ALTER COLUMN error_code SET STORAGE EXTERNAL;
ALTER TABLE ONLY public.webhook_delivery ALTER COLUMN req_data SET STORAGE EXTERNAL;
ALTER TABLE ONLY public.webhook_delivery ALTER COLUMN rsp_data SET STORAGE EXTERNAL;


--
-- Name: file_data_00; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_data ATTACH PARTITION public.file_data_00 FOR VALUES WITH (modulus 16, remainder 0);


--
-- Name: file_data_01; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_data ATTACH PARTITION public.file_data_01 FOR VALUES WITH (modulus 16, remainder 1);


--
-- Name: file_data_02; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_data ATTACH PARTITION public.file_data_02 FOR VALUES WITH (modulus 16, remainder 2);


--
-- Name: file_data_03; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_data ATTACH PARTITION public.file_data_03 FOR VALUES WITH (modulus 16, remainder 3);


--
-- Name: file_data_04; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_data ATTACH PARTITION public.file_data_04 FOR VALUES WITH (modulus 16, remainder 4);


--
-- Name: file_data_05; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_data ATTACH PARTITION public.file_data_05 FOR VALUES WITH (modulus 16, remainder 5);


--
-- Name: file_data_06; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_data ATTACH PARTITION public.file_data_06 FOR VALUES WITH (modulus 16, remainder 6);


--
-- Name: file_data_07; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_data ATTACH PARTITION public.file_data_07 FOR VALUES WITH (modulus 16, remainder 7);


--
-- Name: file_data_08; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_data ATTACH PARTITION public.file_data_08 FOR VALUES WITH (modulus 16, remainder 8);


--
-- Name: file_data_09; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_data ATTACH PARTITION public.file_data_09 FOR VALUES WITH (modulus 16, remainder 9);


--
-- Name: file_data_10; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_data ATTACH PARTITION public.file_data_10 FOR VALUES WITH (modulus 16, remainder 10);


--
-- Name: file_data_11; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_data ATTACH PARTITION public.file_data_11 FOR VALUES WITH (modulus 16, remainder 11);


--
-- Name: file_data_12; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_data ATTACH PARTITION public.file_data_12 FOR VALUES WITH (modulus 16, remainder 12);


--
-- Name: file_data_13; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_data ATTACH PARTITION public.file_data_13 FOR VALUES WITH (modulus 16, remainder 13);


--
-- Name: file_data_14; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_data ATTACH PARTITION public.file_data_14 FOR VALUES WITH (modulus 16, remainder 14);


--
-- Name: file_data_15; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_data ATTACH PARTITION public.file_data_15 FOR VALUES WITH (modulus 16, remainder 15);


--
-- Data for Name: access_token; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.access_token (id, profile_id, created_at, updated_at, name, token, perms, expires_at) FROM stdin;
\.


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_log (id, name, type, created_at, archived_at, profile_id, props, ip_addr, tracked_at, source, context) FROM stdin;
\.


--
-- Data for Name: comment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.comment (id, thread_id, owner_id, created_at, modified_at, content, mentions) FROM stdin;
\.


--
-- Data for Name: comment_thread; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.comment_thread (id, file_id, owner_id, created_at, modified_at, page_id, participants, seqn, "position", is_resolved, page_name, frame_id, mentions) FROM stdin;
\.


--
-- Data for Name: comment_thread_status; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.comment_thread_status (thread_id, profile_id, created_at, modified_at) FROM stdin;
\.


--
-- Data for Name: file; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.file (id, project_id, created_at, modified_at, deleted_at, name, is_shared, has_media_trimmed, revn, data, ignore_sync_until, comment_thread_seqn, data_backend, features, version, data_ref_id, vern) FROM stdin;
\.


--
-- Data for Name: file_change; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.file_change (id, file_id, created_at, session_id, revn, data, changes, profile_id, features, label, data_backend, data_ref_id, version, created_by, updated_at, deleted_at, migrations, locked_by) FROM stdin;
\.


--
-- Data for Name: file_data_00; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.file_data_00 (file_id, id, created_at, modified_at, deleted_at, type, backend, metadata, data) FROM stdin;
\.


--
-- Data for Name: file_data_01; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.file_data_01 (file_id, id, created_at, modified_at, deleted_at, type, backend, metadata, data) FROM stdin;
\.


--
-- Data for Name: file_data_02; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.file_data_02 (file_id, id, created_at, modified_at, deleted_at, type, backend, metadata, data) FROM stdin;
\.


--
-- Data for Name: file_data_03; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.file_data_03 (file_id, id, created_at, modified_at, deleted_at, type, backend, metadata, data) FROM stdin;
\.


--
-- Data for Name: file_data_04; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.file_data_04 (file_id, id, created_at, modified_at, deleted_at, type, backend, metadata, data) FROM stdin;
\.


--
-- Data for Name: file_data_05; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.file_data_05 (file_id, id, created_at, modified_at, deleted_at, type, backend, metadata, data) FROM stdin;
\.


--
-- Data for Name: file_data_06; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.file_data_06 (file_id, id, created_at, modified_at, deleted_at, type, backend, metadata, data) FROM stdin;
\.


--
-- Data for Name: file_data_07; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.file_data_07 (file_id, id, created_at, modified_at, deleted_at, type, backend, metadata, data) FROM stdin;
\.


--
-- Data for Name: file_data_08; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.file_data_08 (file_id, id, created_at, modified_at, deleted_at, type, backend, metadata, data) FROM stdin;
\.


--
-- Data for Name: file_data_09; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.file_data_09 (file_id, id, created_at, modified_at, deleted_at, type, backend, metadata, data) FROM stdin;
\.


--
-- Data for Name: file_data_10; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.file_data_10 (file_id, id, created_at, modified_at, deleted_at, type, backend, metadata, data) FROM stdin;
\.


--
-- Data for Name: file_data_11; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.file_data_11 (file_id, id, created_at, modified_at, deleted_at, type, backend, metadata, data) FROM stdin;
\.


--
-- Data for Name: file_data_12; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.file_data_12 (file_id, id, created_at, modified_at, deleted_at, type, backend, metadata, data) FROM stdin;
\.


--
-- Data for Name: file_data_13; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.file_data_13 (file_id, id, created_at, modified_at, deleted_at, type, backend, metadata, data) FROM stdin;
\.


--
-- Data for Name: file_data_14; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.file_data_14 (file_id, id, created_at, modified_at, deleted_at, type, backend, metadata, data) FROM stdin;
\.


--
-- Data for Name: file_data_15; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.file_data_15 (file_id, id, created_at, modified_at, deleted_at, type, backend, metadata, data) FROM stdin;
\.


--
-- Data for Name: file_data_fragment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.file_data_fragment (id, file_id, created_at, metadata, deleted_at, data, data_backend, data_ref_id) FROM stdin;
\.


--
-- Data for Name: file_library_rel; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.file_library_rel (file_id, library_file_id, created_at, synced_at) FROM stdin;
\.


--
-- Data for Name: file_media_object; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.file_media_object (id, created_at, deleted_at, name, width, height, mtype, file_id, is_local, media_id, thumbnail_id) FROM stdin;
\.


--
-- Data for Name: file_migration; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.file_migration (file_id, name, created_at) FROM stdin;
\.


--
-- Data for Name: file_object_thumbnail; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.file_object_thumbnail (file_id, object_id, created_at, data, media_id) FROM stdin;
\.


--
-- Data for Name: file_profile_rel; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.file_profile_rel (file_id, profile_id, created_at, modified_at, is_owner, is_admin, can_edit) FROM stdin;
\.


--
-- Data for Name: file_tagged_object_thumbnail; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.file_tagged_object_thumbnail (file_id, tag, object_id, media_id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: file_thumbnail; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.file_thumbnail (file_id, revn, created_at, updated_at, deleted_at, data, props, media_id) FROM stdin;
\.


--
-- Data for Name: global_complaint_report; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.global_complaint_report (email, created_at, type, content) FROM stdin;
\.


--
-- Data for Name: http_session; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.http_session (id, created_at, profile_id, user_agent, updated_at) FROM stdin;
\.


--
-- Data for Name: http_session_v2; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.http_session_v2 (id, created_at, modified_at, profile_id, user_agent, sso_provider_id, sso_session_id) FROM stdin;
d480a671-7255-80d5-8007-e62ea52ae33a	2026-04-20 16:12:30.763472+00	2026-04-20 16:12:30.763472+00	d480a671-7255-80d5-8007-e62ea5265396	python-requests/2.32.5	\N	\N
d480a671-7255-80d5-8007-e62ea54771ea	2026-04-20 16:12:30.877309+00	2026-04-20 16:12:30.877309+00	d480a671-7255-80d5-8007-e62ea545dcd6	python-requests/2.32.5	\N	\N
d480a671-7255-80d5-8007-e62ea5621b02	2026-04-20 16:12:30.984213+00	2026-04-20 16:12:30.984213+00	d480a671-7255-80d5-8007-e62ea560817c	python-requests/2.32.5	\N	\N
d480a671-7255-80d5-8007-e62ea57e2d0d	2026-04-20 16:12:31.096166+00	2026-04-20 16:12:31.096166+00	d480a671-7255-80d5-8007-e62ea57c6f76	python-requests/2.32.5	\N	\N
d480a671-7255-80d5-8007-e62ea59a20ad	2026-04-20 16:12:31.208783+00	2026-04-20 16:12:31.208783+00	d480a671-7255-80d5-8007-e62ea5980177	python-requests/2.32.5	\N	\N
d480a671-7255-80d5-8007-e62ea5c1d2d8	2026-04-20 16:12:31.367241+00	2026-04-20 16:12:31.367241+00	d480a671-7255-80d5-8007-e62ea5bfccfd	python-requests/2.32.5	\N	\N
d480a671-7255-80d5-8007-e62ea5dc41bf	2026-04-20 16:12:31.473018+00	2026-04-20 16:12:31.473018+00	d480a671-7255-80d5-8007-e62ea5db0605	python-requests/2.32.5	\N	\N
d480a671-7255-80d5-8007-e62ea5f801e7	2026-04-20 16:12:31.584722+00	2026-04-20 16:12:31.584722+00	d480a671-7255-80d5-8007-e62ea5f69826	python-requests/2.32.5	\N	\N
d480a671-7255-80d5-8007-e62ea615e519	2026-04-20 16:12:31.703043+00	2026-04-20 16:12:31.703043+00	d480a671-7255-80d5-8007-e62ea6147c7f	python-requests/2.32.5	\N	\N
d480a671-7255-80d5-8007-e62ea62eed32	2026-04-20 16:12:31.803886+00	2026-04-20 16:12:31.803886+00	d480a671-7255-80d5-8007-e62ea5265396	python-requests/2.32.5	\N	\N
d480a671-7255-80d5-8007-e62ea6513796	2026-04-20 16:12:31.940677+00	2026-04-20 16:12:31.940677+00	d480a671-7255-80d5-8007-e62ea545dcd6	python-requests/2.32.5	\N	\N
d480a671-7255-80d5-8007-e62ea66d98af	2026-04-20 16:12:32.054411+00	2026-04-20 16:12:32.054411+00	d480a671-7255-80d5-8007-e62ea5265396	python-requests/2.32.5	\N	\N
d480a671-7255-80d5-8007-e62ea68d3c56	2026-04-20 16:12:32.180372+00	2026-04-20 16:12:32.180372+00	d480a671-7255-80d5-8007-e62ea545dcd6	python-requests/2.32.5	\N	\N
d480a671-7255-80d5-8007-e62ea6abe987	2026-04-20 16:12:32.303617+00	2026-04-20 16:12:32.303617+00	d480a671-7255-80d5-8007-e62ea560817c	python-requests/2.32.5	\N	\N
d480a671-7255-80d5-8007-e62ea6c73312	2026-04-20 16:12:32.41293+00	2026-04-20 16:12:32.41293+00	d480a671-7255-80d5-8007-e62ea57c6f76	python-requests/2.32.5	\N	\N
d480a671-7255-80d5-8007-e62ea6e4d96f	2026-04-20 16:12:32.531109+00	2026-04-20 16:12:32.531109+00	d480a671-7255-80d5-8007-e62ea5980177	python-requests/2.32.5	\N	\N
d480a671-7255-80d5-8007-e62ea701a7c0	2026-04-20 16:12:32.646968+00	2026-04-20 16:12:32.646968+00	d480a671-7255-80d5-8007-e62ea5bfccfd	python-requests/2.32.5	\N	\N
d480a671-7255-80d5-8007-e62ea71ebc90	2026-04-20 16:12:32.762303+00	2026-04-20 16:12:32.762303+00	d480a671-7255-80d5-8007-e62ea5db0605	python-requests/2.32.5	\N	\N
d480a671-7255-80d5-8007-e62ea73b7e57	2026-04-20 16:12:32.877838+00	2026-04-20 16:12:32.877838+00	d480a671-7255-80d5-8007-e62ea5f69826	python-requests/2.32.5	\N	\N
d480a671-7255-80d5-8007-e62ea7585071	2026-04-20 16:12:32.993976+00	2026-04-20 16:12:32.993976+00	d480a671-7255-80d5-8007-e62ea6147c7f	python-requests/2.32.5	\N	\N
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.migrations (module, step, created_at) FROM stdin;
main	0001-add-extensions	2026-04-20 16:12:27.854897
main	0002-add-profile-tables	2026-04-20 16:12:27.854897
main	0003-add-project-tables	2026-04-20 16:12:27.854897
main	0004-add-tasks-tables	2026-04-20 16:12:27.854897
main	0005-add-libraries-tables	2026-04-20 16:12:27.854897
main	0006-add-presence-tables	2026-04-20 16:12:27.854897
main	0007-drop-version-field-from-page-table	2026-04-20 16:12:27.854897
main	0008-add-generic-token-table	2026-04-20 16:12:27.854897
main	0009-drop-profile-email-table	2026-04-20 16:12:27.854897
main	0010-add-http-session-table	2026-04-20 16:12:27.854897
main	0011-add-session-id-field-to-page-change-table	2026-04-20 16:12:27.854897
main	0012-make-libraries-linked-to-a-file	2026-04-20 16:12:27.854897
main	0013-mark-files-shareable	2026-04-20 16:12:27.854897
main	0014-refactor-media-storage.sql	2026-04-20 16:12:27.854897
main	0015-improve-tasks-tables	2026-04-20 16:12:27.854897
main	0016-truncate-and-alter-tokens-table	2026-04-20 16:12:27.854897
main	0017-link-files-to-libraries	2026-04-20 16:12:27.854897
main	0018-add-file-trimming-triggers	2026-04-20 16:12:27.854897
main	0019-add-improved-scheduled-tasks	2026-04-20 16:12:27.854897
main	0020-minor-fixes-to-media-object	2026-04-20 16:12:27.854897
main	0021-http-session-improvements	2026-04-20 16:12:27.854897
main	0022-page-file-refactor	2026-04-20 16:12:27.854897
main	0023-adapt-old-pages-and-files	2026-04-20 16:12:27.854897
main	0024-mod-profile-table	2026-04-20 16:12:27.854897
main	0025-del-generic-tokens-table	2026-04-20 16:12:27.854897
main	0026-mod-file-library-rel-table-synced-date	2026-04-20 16:12:27.854897
main	0027-mod-file-table-ignore-sync	2026-04-20 16:12:27.854897
main	0028-add-team-project-profile-rel-table	2026-04-20 16:12:27.854897
main	0029-del-project-profile-rel-indexes	2026-04-20 16:12:27.854897
main	0030-mod-file-table-add-missing-index	2026-04-20 16:12:27.854897
main	0031-add-conversation-related-tables	2026-04-20 16:12:27.854897
main	0032-del-unused-tables	2026-04-20 16:12:27.854897
main	0033-mod-comment-thread-table	2026-04-20 16:12:27.854897
main	0034-mod-profile-table-add-props-field	2026-04-20 16:12:27.854897
main	0035-add-storage-tables	2026-04-20 16:12:27.854897
main	0036-mod-storage-referenced-tables	2026-04-20 16:12:27.854897
main	0037-del-obsolete-triggers	2026-04-20 16:12:27.854897
main	0038-add-storage-on-delete-triggers	2026-04-20 16:12:27.854897
main	0039-fix-some-on-delete-triggers	2026-04-20 16:12:27.854897
main	0040-add-error-report-tables	2026-04-20 16:12:27.854897
main	0041-mod-pg-storage-options	2026-04-20 16:12:27.854897
main	0042-add-server-prop-table	2026-04-20 16:12:27.854897
main	0043-drop-old-tables-and-fields	2026-04-20 16:12:27.854897
main	0044-add-storage-refcount	2026-04-20 16:12:27.854897
main	0045-add-index-to-file-change-table	2026-04-20 16:12:27.854897
main	0046-add-profile-complaint-table	2026-04-20 16:12:27.854897
main	0047-mod-file-change-table	2026-04-20 16:12:27.854897
main	0048-mod-storage-tables	2026-04-20 16:12:27.854897
main	0049-mod-http-session-table	2026-04-20 16:12:27.854897
main	0050-mod-server-prop-table	2026-04-20 16:12:27.854897
main	0051-mod-file-library-rel-table	2026-04-20 16:12:27.854897
main	0052-del-legacy-user-and-team	2026-04-20 16:12:27.854897
main	0053-add-team-font-variant-table	2026-04-20 16:12:27.854897
main	0054-add-audit-log-table	2026-04-20 16:12:27.854897
main	0055-mod-file-media-object-table	2026-04-20 16:12:27.854897
main	0056-add-missing-index-on-deleted-at	2026-04-20 16:12:27.854897
main	0057-del-profile-on-delete-trigger	2026-04-20 16:12:27.854897
main	0058-del-team-on-delete-trigger	2026-04-20 16:12:27.854897
main	0059-mod-audit-log-table	2026-04-20 16:12:27.854897
main	0060-mod-file-change-table	2026-04-20 16:12:27.854897
main	0061-mod-file-table	2026-04-20 16:12:27.854897
main	0062-fix-metadata-media	2026-04-20 16:12:27.854897
main	0063-add-share-link-table	2026-04-20 16:12:27.854897
main	0064-mod-audit-log-table	2026-04-20 16:12:27.854897
main	0065-add-trivial-spelling-fixes	2026-04-20 16:12:27.854897
main	0066-add-frame-thumbnail-table	2026-04-20 16:12:27.854897
main	0067-add-team-invitation-table	2026-04-20 16:12:27.854897
main	0068-mod-storage-object-table	2026-04-20 16:12:27.854897
main	0069-add-file-thumbnail-table	2026-04-20 16:12:27.854897
main	0070-del-frame-thumbnail-table	2026-04-20 16:12:27.854897
main	0071-add-file-object-thumbnail-table	2026-04-20 16:12:27.854897
main	0072-mod-file-object-thumbnail-table	2026-04-20 16:12:27.854897
main	0073-mod-file-media-object-constraints	2026-04-20 16:12:27.854897
main	0074-mod-file-library-rel-constraints	2026-04-20 16:12:27.854897
main	0075-mod-share-link-table	2026-04-20 16:12:27.854897
main	0076-mod-storage-object-table	2026-04-20 16:12:27.854897
main	0077-mod-comment-thread-table	2026-04-20 16:12:27.854897
main	0078-mod-file-media-object-table-drop-cascade	2026-04-20 16:12:27.854897
main	0079-mod-profile-table	2026-04-20 16:12:27.854897
main	0080-mod-index-names	2026-04-20 16:12:27.854897
main	0081-add-deleted-at-index-to-file-table	2026-04-20 16:12:27.854897
main	0082-add-features-column-to-file-table	2026-04-20 16:12:27.854897
main	0083-add-file-data-fragment-table	2026-04-20 16:12:27.854897
main	0084-add-features-column-to-file-change-table	2026-04-20 16:12:27.854897
main	0085-add-webhook-table	2026-04-20 16:12:27.854897
main	0086-add-webhook-delivery-table	2026-04-20 16:12:27.854897
main	0087-mod-task-table	2026-04-20 16:12:27.854897
main	0088-mod-team-profile-rel-table	2026-04-20 16:12:27.854897
main	0089-mod-project-profile-rel-table	2026-04-20 16:12:27.854897
main	0090-mod-http-session-table	2026-04-20 16:12:27.854897
main	0091-mod-team-project-profile-rel-table	2026-04-20 16:12:27.854897
main	0092-mod-team-invitation-table	2026-04-20 16:12:27.854897
main	0093-del-file-share-tokens-table	2026-04-20 16:12:27.854897
main	0094-del-profile-attr-table	2026-04-20 16:12:27.854897
main	0095-del-storage-data-table	2026-04-20 16:12:27.854897
main	0096-del-storage-pending-table	2026-04-20 16:12:27.854897
main	0098-add-quotes-table	2026-04-20 16:12:27.854897
main	0099-add-access-token-table	2026-04-20 16:12:27.854897
main	0100-mod-profile-indexes	2026-04-20 16:12:27.854897
main	0101-mod-server-error-report-table	2026-04-20 16:12:27.854897
main	0102-mod-access-token-table	2026-04-20 16:12:27.854897
main	0103-mod-file-object-thumbnail-table	2026-04-20 16:12:27.854897
main	0104-mod-file-thumbnail-table	2026-04-20 16:12:27.854897
main	0105-mod-file-change-table	2026-04-20 16:12:27.854897
main	0105-mod-server-error-report-table	2026-04-20 16:12:27.854897
main	0106-add-file-tagged-object-thumbnail-table	2026-04-20 16:12:27.854897
main	0106-mod-team-table	2026-04-20 16:12:27.854897
main	0107-mod-file-tagged-object-thumbnail-table	2026-04-20 16:12:27.854897
main	0107-add-deletion-protection-trigger-function	2026-04-20 16:12:27.854897
main	0108-mod-file-thumbnail-table	2026-04-20 16:12:27.854897
main	0109-mod-file-tagged-object-thumbnail-table	2026-04-20 16:12:27.854897
main	0110-mod-file-media-object-table	2026-04-20 16:12:27.854897
main	0111-mod-file-data-fragment-table	2026-04-20 16:12:27.854897
main	0112-mod-profile-table	2026-04-20 16:12:27.854897
main	0113-mod-team-font-variant-table	2026-04-20 16:12:27.854897
main	0114-mod-team-table	2026-04-20 16:12:27.854897
main	0115-mod-project-table	2026-04-20 16:12:27.854897
main	0116-mod-file-table	2026-04-20 16:12:27.854897
main	0117-mod-file-object-thumbnail-table	2026-04-20 16:12:27.854897
main	0118-mod-task-table	2026-04-20 16:12:27.854897
main	0119-mod-file-table	2026-04-20 16:12:27.854897
main	0120-mod-audit-log-table	2026-04-20 16:12:27.854897
main	0121-mod-file-data-fragment-table	2026-04-20 16:12:27.854897
main	0122-mod-file-table	2026-04-20 16:12:27.854897
main	0122-mod-file-data-fragment-table	2026-04-20 16:12:27.854897
main	0123-mod-file-change-table	2026-04-20 16:12:27.854897
main	0124-mod-profile-table	2026-04-20 16:12:27.854897
main	0125-mod-file-table	2026-04-20 16:12:27.854897
main	0126-add-team-access-request-table	2026-04-20 16:12:27.854897
main	0127-mod-storage-object-table	2026-04-20 16:12:27.854897
main	0128-mod-task-table	2026-04-20 16:12:27.854897
main	0129-mod-file-change-table	2026-04-20 16:12:27.854897
main	0130-mod-file-change-table	2026-04-20 16:12:27.854897
main	0131-mod-webhook-table	2026-04-20 16:12:27.854897
main	0132-mod-file-change-table	2026-04-20 16:12:27.854897
main	0133-mod-file-table	2026-04-20 16:12:27.854897
main	0134-mod-file-change-table	2026-04-20 16:12:27.854897
main	0135-mod-team-invitation-table.sql	2026-04-20 16:12:27.854897
main	0136-mod-comments-mentions.sql	2026-04-20 16:12:27.854897
main	0137-add-file-migration-table.sql	2026-04-20 16:12:27.854897
main	0138-mod-file-data-fragment-table.sql	2026-04-20 16:12:27.854897
main	0139-mod-file-change-table.sql	2026-04-20 16:12:27.854897
main	0140-mod-file-change-table.sql	2026-04-20 16:12:27.854897
main	0140-add-locked-by-column-to-file-change-table	2026-04-20 16:12:27.854897
main	0141-add-idx-to-file-library-rel	2026-04-20 16:12:27.854897
main	0141-add-file-data-table.sql	2026-04-20 16:12:27.854897
main	0142-add-sso-provider-table	2026-04-20 16:12:27.854897
main	0143-http-session-v2-table	2026-04-20 16:12:27.854897
main	0144-mod-server-error-report-table	2026-04-20 16:12:27.854897
main	0145-fix-plugins-uri-on-profile	2026-04-20 16:12:27.854897
\.


--
-- Data for Name: presence; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.presence (file_id, profile_id, session_id, updated_at) FROM stdin;
\.


--
-- Data for Name: profile; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.profile (id, created_at, modified_at, deleted_at, fullname, email, password, lang, theme, is_demo, is_active, props, photo_id, is_muted, auth_backend, is_blocked, default_project_id, default_team_id) FROM stdin;
d480a671-7255-80d5-8007-e62ea6147c7f	2026-04-20 16:12:31.698674+00	2026-04-20 16:12:31.698674+00	\N	Henry Park	henry@designstudio.io	argon2id$6656765152e2fd5b42d3285aad32bdd6$32768$3$2$39959f76b28561c1c96cb36a251baaa7479f4df51ad5ebfac1fa1e0f29f1b5e7	\N	\N	f	t	{"~:nudge": {"~:big": 10, "~:small": 1}, "~:v2-info-shown": true, "~:viewed-tutorial?": true, "~:onboarding-viewed": true, "~:newsletter-updates": false, "~:viewed-walkthrough?": true, "~:release-notes-viewed": "2.14"}	\N	f	penpot	f	d480a671-7255-80d5-8007-e62ea6153552	d480a671-7255-80d5-8007-e62ea614ddc8
d480a671-7255-80d5-8007-e62ea5265396	2026-04-20 16:12:30.747609+00	2026-04-20 16:12:30.747609+00	\N	Penpot Admin	admin@penpot.local	argon2id$e7c268e0233a283270260ffa9f461ef1$32768$3$2$73be864b011d1696c142c3077f21994946d8ae5b210d2da4f55ed14d6a94cd07	\N	\N	f	t	{"~:nudge": {"~:big": 10, "~:small": 1}, "~:v2-info-shown": true, "~:viewed-tutorial?": true, "~:onboarding-viewed": true, "~:newsletter-updates": false, "~:viewed-walkthrough?": true, "~:release-notes-viewed": "2.14"}	\N	f	penpot	f	d480a671-7255-80d5-8007-e62ea529418c	d480a671-7255-80d5-8007-e62ea52793a7
d480a671-7255-80d5-8007-e62ea545dcd6	2026-04-20 16:12:30.872588+00	2026-04-20 16:12:30.872588+00	\N	Alice Chen	alice@designstudio.io	argon2id$958a61af9c4d7107c4f00db6e44a6a6c$32768$3$2$14527387eacb507803e1850d0aa6cb5b23aa4cd8608f8164945a074762a88ba1	\N	\N	f	t	{"~:nudge": {"~:big": 10, "~:small": 1}, "~:v2-info-shown": true, "~:viewed-tutorial?": true, "~:onboarding-viewed": true, "~:newsletter-updates": false, "~:viewed-walkthrough?": true, "~:release-notes-viewed": "2.14"}	\N	f	penpot	f	d480a671-7255-80d5-8007-e62ea5468b49	d480a671-7255-80d5-8007-e62ea5466832
d480a671-7255-80d5-8007-e62ea560817c	2026-04-20 16:12:30.979641+00	2026-04-20 16:12:30.979641+00	\N	Bob Martin	bob@designstudio.io	argon2id$810fa3f9b905441831b543ca43a5bdf8$32768$3$2$4db1c31c52d24a7fad5a4406b1ce600d9c398120aae755efcf9dab15bd15eded	\N	\N	f	t	{"~:nudge": {"~:big": 10, "~:small": 1}, "~:v2-info-shown": true, "~:viewed-tutorial?": true, "~:onboarding-viewed": true, "~:newsletter-updates": false, "~:viewed-walkthrough?": true, "~:release-notes-viewed": "2.14"}	\N	f	penpot	f	d480a671-7255-80d5-8007-e62ea5614446	d480a671-7255-80d5-8007-e62ea5610015
d480a671-7255-80d5-8007-e62ea57c6f76	2026-04-20 16:12:31.09085+00	2026-04-20 16:12:31.09085+00	\N	Carol Jones	carol@designstudio.io	argon2id$a07beaa011c94ca92d2c2722a05f3b32$32768$3$2$4571720b69d28000f995060a53d16b9070bcdf75ded764dc911b0472ff0c369c	\N	\N	f	t	{"~:nudge": {"~:big": 10, "~:small": 1}, "~:v2-info-shown": true, "~:viewed-tutorial?": true, "~:onboarding-viewed": true, "~:newsletter-updates": false, "~:viewed-walkthrough?": true, "~:release-notes-viewed": "2.14"}	\N	f	penpot	f	d480a671-7255-80d5-8007-e62ea57d3542	d480a671-7255-80d5-8007-e62ea57cf250
d480a671-7255-80d5-8007-e62ea5980177	2026-04-20 16:12:31.202827+00	2026-04-20 16:12:31.202827+00	\N	David Kim	david@designstudio.io	argon2id$fd5f116b444ab699284928a6ded358af$32768$3$2$19c8be13b5a5070a9962038edf218ec97bab628c1ebcf178060ef804e6f1bff8	\N	\N	f	t	{"~:nudge": {"~:big": 10, "~:small": 1}, "~:v2-info-shown": true, "~:viewed-tutorial?": true, "~:onboarding-viewed": true, "~:newsletter-updates": false, "~:viewed-walkthrough?": true, "~:release-notes-viewed": "2.14"}	\N	f	penpot	f	d480a671-7255-80d5-8007-e62ea599373c	d480a671-7255-80d5-8007-e62ea598e352
d480a671-7255-80d5-8007-e62ea5bfccfd	2026-04-20 16:12:31.361162+00	2026-04-20 16:12:31.361162+00	\N	Emma Wilson	emma@designstudio.io	argon2id$eabc031be08d6dce72e71b9ce5c92408$32768$3$2$d31e5d777635e84a164f98ce04ae00ce75f00570ca54bae308b02daaf2621ae7	\N	\N	f	t	{"~:nudge": {"~:big": 10, "~:small": 1}, "~:v2-info-shown": true, "~:viewed-tutorial?": true, "~:onboarding-viewed": true, "~:newsletter-updates": false, "~:viewed-walkthrough?": true, "~:release-notes-viewed": "2.14"}	\N	f	penpot	f	d480a671-7255-80d5-8007-e62ea5c0e491	d480a671-7255-80d5-8007-e62ea5c0be6b
d480a671-7255-80d5-8007-e62ea5db0605	2026-04-20 16:12:31.469751+00	2026-04-20 16:12:31.469751+00	\N	Frank Oz	frank@designstudio.io	argon2id$c2cf784346a8cc21f762286cceba0843$32768$3$2$81e8d3f4642853833999216f6a0ddf78d7a848ff0e508f8f1f815c75f193f012	\N	\N	f	t	{"~:nudge": {"~:big": 10, "~:small": 1}, "~:v2-info-shown": true, "~:viewed-tutorial?": true, "~:onboarding-viewed": true, "~:newsletter-updates": false, "~:viewed-walkthrough?": true, "~:release-notes-viewed": "2.14"}	\N	f	penpot	f	d480a671-7255-80d5-8007-e62ea5dba333	d480a671-7255-80d5-8007-e62ea5dba332
d480a671-7255-80d5-8007-e62ea5f69826	2026-04-20 16:12:31.580074+00	2026-04-20 16:12:31.580074+00	\N	Grace Lee	grace@designstudio.io	argon2id$46bc9094e59f15926f2f8480f8a6b5a2$32768$3$2$cd3ceb89b80970ad4bd8c725a137553493c7679519075e13b8e9a24a9fc5656d	\N	\N	f	t	{"~:nudge": {"~:big": 10, "~:small": 1}, "~:v2-info-shown": true, "~:viewed-tutorial?": true, "~:onboarding-viewed": true, "~:newsletter-updates": false, "~:viewed-walkthrough?": true, "~:release-notes-viewed": "2.14"}	\N	f	penpot	f	d480a671-7255-80d5-8007-e62ea5f75295	d480a671-7255-80d5-8007-e62ea5f721e7
\.


--
-- Data for Name: profile_complaint_report; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.profile_complaint_report (profile_id, created_at, type, content) FROM stdin;
\.


--
-- Data for Name: project; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.project (id, team_id, created_at, modified_at, deleted_at, is_default, name) FROM stdin;
d480a671-7255-80d5-8007-e62ea529418c	d480a671-7255-80d5-8007-e62ea52793a7	2026-04-20 16:12:30.757599+00	2026-04-20 16:12:30.757599+00	\N	t	Drafts
d480a671-7255-80d5-8007-e62ea5468b49	d480a671-7255-80d5-8007-e62ea5466832	2026-04-20 16:12:30.87428+00	2026-04-20 16:12:30.87428+00	\N	t	Drafts
d480a671-7255-80d5-8007-e62ea5614446	d480a671-7255-80d5-8007-e62ea5610015	2026-04-20 16:12:30.98127+00	2026-04-20 16:12:30.981271+00	\N	t	Drafts
d480a671-7255-80d5-8007-e62ea57d3542	d480a671-7255-80d5-8007-e62ea57cf250	2026-04-20 16:12:31.092775+00	2026-04-20 16:12:31.092776+00	\N	t	Drafts
d480a671-7255-80d5-8007-e62ea599373c	d480a671-7255-80d5-8007-e62ea598e352	2026-04-20 16:12:31.205108+00	2026-04-20 16:12:31.205108+00	\N	t	Drafts
d480a671-7255-80d5-8007-e62ea5c0e491	d480a671-7255-80d5-8007-e62ea5c0be6b	2026-04-20 16:12:31.36397+00	2026-04-20 16:12:31.36397+00	\N	t	Drafts
d480a671-7255-80d5-8007-e62ea5dba333	d480a671-7255-80d5-8007-e62ea5dba332	2026-04-20 16:12:31.470853+00	2026-04-20 16:12:31.470853+00	\N	t	Drafts
d480a671-7255-80d5-8007-e62ea5f75295	d480a671-7255-80d5-8007-e62ea5f721e7	2026-04-20 16:12:31.581845+00	2026-04-20 16:12:31.581845+00	\N	t	Drafts
d480a671-7255-80d5-8007-e62ea6153552	d480a671-7255-80d5-8007-e62ea614ddc8	2026-04-20 16:12:31.700505+00	2026-04-20 16:12:31.700505+00	\N	t	Drafts
\.


--
-- Data for Name: project_profile_rel; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.project_profile_rel (profile_id, project_id, created_at, modified_at, is_owner, is_admin, can_edit, id) FROM stdin;
d480a671-7255-80d5-8007-e62ea5265396	d480a671-7255-80d5-8007-e62ea529418c	2026-04-20 16:12:30.758692+00	2026-04-20 16:12:30.758692+00	t	t	t	213f114f-cce3-42cf-aa9d-7b03514b1d10
d480a671-7255-80d5-8007-e62ea545dcd6	d480a671-7255-80d5-8007-e62ea5468b49	2026-04-20 16:12:30.874738+00	2026-04-20 16:12:30.874738+00	t	t	t	2e7db163-b5ec-439f-bc23-7c596247b166
d480a671-7255-80d5-8007-e62ea560817c	d480a671-7255-80d5-8007-e62ea5614446	2026-04-20 16:12:30.981795+00	2026-04-20 16:12:30.981795+00	t	t	t	4b240c73-3e40-4c35-9828-710199df73f2
d480a671-7255-80d5-8007-e62ea57c6f76	d480a671-7255-80d5-8007-e62ea57d3542	2026-04-20 16:12:31.093298+00	2026-04-20 16:12:31.093298+00	t	t	t	5b22c659-5e4d-4142-a0f0-d459d0386f75
d480a671-7255-80d5-8007-e62ea5980177	d480a671-7255-80d5-8007-e62ea599373c	2026-04-20 16:12:31.205654+00	2026-04-20 16:12:31.205654+00	t	t	t	3bfe618e-d095-4cd8-847a-e29fac4926ff
d480a671-7255-80d5-8007-e62ea5bfccfd	d480a671-7255-80d5-8007-e62ea5c0e491	2026-04-20 16:12:31.364598+00	2026-04-20 16:12:31.364598+00	t	t	t	0b50f7c1-d475-445c-968a-9ada7a039c1b
d480a671-7255-80d5-8007-e62ea5db0605	d480a671-7255-80d5-8007-e62ea5dba333	2026-04-20 16:12:31.471106+00	2026-04-20 16:12:31.471107+00	t	t	t	1cd0b7ca-7f57-445a-bffd-af9e731c8e88
d480a671-7255-80d5-8007-e62ea5f69826	d480a671-7255-80d5-8007-e62ea5f75295	2026-04-20 16:12:31.582162+00	2026-04-20 16:12:31.582162+00	t	t	t	3880848f-8444-41b9-acc4-68c5d159fd1a
d480a671-7255-80d5-8007-e62ea6147c7f	d480a671-7255-80d5-8007-e62ea6153552	2026-04-20 16:12:31.700777+00	2026-04-20 16:12:31.700777+00	t	t	t	d14ab89b-a440-4365-8ccf-5ed24fe786fd
\.


--
-- Data for Name: scheduled_task; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.scheduled_task (id, created_at, modified_at, cron_expr) FROM stdin;
session-gc	2026-04-20 16:12:29.411726+00	2026-04-20 16:12:29.411726+00	0 0 0 * * ?
objects-gc	2026-04-20 16:12:29.412121+00	2026-04-20 16:12:29.412121+00	0 0 0 * * ?
storage-gc-deleted	2026-04-20 16:12:29.412307+00	2026-04-20 16:12:29.412307+00	0 0 0 * * ?
storage-gc-touched	2026-04-20 16:12:29.412488+00	2026-04-20 16:12:29.412488+00	0 0 0 * * ?
tasks-gc	2026-04-20 16:12:29.412665+00	2026-04-20 16:12:29.412665+00	0 0 0 * * ?
file-gc-scheduler	2026-04-20 16:12:29.412804+00	2026-04-20 16:12:29.412804+00	0 0 2 * * ?
telemetry	2026-04-20 16:12:29.412936+00	2026-04-20 16:12:29.412936+00	0 30 */3,23 * * ?
\.


--
-- Data for Name: scheduled_task_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.scheduled_task_history (id, task_id, created_at, is_error, reason) FROM stdin;
\.


--
-- Data for Name: server_error_report; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.server_error_report (id, created_at, content, version) FROM stdin;
\.


--
-- Data for Name: server_prop; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.server_prop (id, content, preload) FROM stdin;
instance-id	{"~#'": "~ud55ad599-f794-4c4f-844d-1e769b31d2bb"}	t
\.


--
-- Data for Name: share_link; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.share_link (id, file_id, owner_id, created_at, pages, flags, who_comment, who_inspect) FROM stdin;
\.


--
-- Data for Name: sso_provider; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sso_provider (id, created_at, modified_at, is_enabled, type, domain, client_id, client_secret, base_uri, token_uri, auth_uri, user_uri, jwks_uri, logout_uri, roles_attr, email_attr, name_attr, user_info_source, scopes, roles) FROM stdin;
\.


--
-- Data for Name: storage_object; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.storage_object (id, created_at, deleted_at, size, backend, metadata, touched_at) FROM stdin;
\.


--
-- Data for Name: task; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.task (id, created_at, modified_at, completed_at, scheduled_at, priority, queue, name, props, error, retry_num, max_retries, status, label) FROM stdin;
\.


--
-- Data for Name: team; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.team (id, created_at, modified_at, deleted_at, name, is_default, photo_id, features) FROM stdin;
d480a671-7255-80d5-8007-e62ea52793a7	2026-04-20 16:12:30.752823+00	2026-04-20 16:12:30.752823+00	\N	Default	t	\N	{fdata/path-data,plugins/runtime,design-tokens/v1,variants/v1,layout/grid,styles/v2,fdata/objects-map,components/v2,fdata/shape-data-type}
d480a671-7255-80d5-8007-e62ea5466832	2026-04-20 16:12:30.873685+00	2026-04-20 16:12:30.873685+00	\N	Default	t	\N	{fdata/path-data,plugins/runtime,design-tokens/v1,variants/v1,layout/grid,styles/v2,fdata/objects-map,components/v2,fdata/shape-data-type}
d480a671-7255-80d5-8007-e62ea5610015	2026-04-20 16:12:30.980716+00	2026-04-20 16:12:30.980716+00	\N	Default	t	\N	{fdata/path-data,plugins/runtime,design-tokens/v1,variants/v1,layout/grid,styles/v2,fdata/objects-map,components/v2,fdata/shape-data-type}
d480a671-7255-80d5-8007-e62ea57cf250	2026-04-20 16:12:31.092214+00	2026-04-20 16:12:31.092214+00	\N	Default	t	\N	{fdata/path-data,plugins/runtime,design-tokens/v1,variants/v1,layout/grid,styles/v2,fdata/objects-map,components/v2,fdata/shape-data-type}
d480a671-7255-80d5-8007-e62ea598e352	2026-04-20 16:12:31.204518+00	2026-04-20 16:12:31.204518+00	\N	Default	t	\N	{fdata/path-data,plugins/runtime,design-tokens/v1,variants/v1,layout/grid,styles/v2,fdata/objects-map,components/v2,fdata/shape-data-type}
d480a671-7255-80d5-8007-e62ea5c0be6b	2026-04-20 16:12:31.362949+00	2026-04-20 16:12:31.362949+00	\N	Default	t	\N	{fdata/path-data,plugins/runtime,design-tokens/v1,variants/v1,layout/grid,styles/v2,fdata/objects-map,components/v2,fdata/shape-data-type}
d480a671-7255-80d5-8007-e62ea5dba332	2026-04-20 16:12:31.470549+00	2026-04-20 16:12:31.470549+00	\N	Default	t	\N	{fdata/path-data,plugins/runtime,design-tokens/v1,variants/v1,layout/grid,styles/v2,fdata/objects-map,components/v2,fdata/shape-data-type}
d480a671-7255-80d5-8007-e62ea5f721e7	2026-04-20 16:12:31.581456+00	2026-04-20 16:12:31.581456+00	\N	Default	t	\N	{fdata/path-data,plugins/runtime,design-tokens/v1,variants/v1,layout/grid,styles/v2,fdata/objects-map,components/v2,fdata/shape-data-type}
d480a671-7255-80d5-8007-e62ea614ddc8	2026-04-20 16:12:31.70005+00	2026-04-20 16:12:31.70005+00	\N	Default	t	\N	{fdata/path-data,plugins/runtime,design-tokens/v1,variants/v1,layout/grid,styles/v2,fdata/objects-map,components/v2,fdata/shape-data-type}
\.


--
-- Data for Name: team_access_request; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.team_access_request (id, team_id, requester_id, valid_until, auto_join_until, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: team_font_variant; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.team_font_variant (id, team_id, profile_id, created_at, modified_at, deleted_at, font_id, font_family, font_weight, font_style, otf_file_id, ttf_file_id, woff1_file_id, woff2_file_id) FROM stdin;
\.


--
-- Data for Name: team_invitation; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.team_invitation (team_id, email_to, role, valid_until, created_at, updated_at, id, created_by) FROM stdin;
\.


--
-- Data for Name: team_profile_rel; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.team_profile_rel (team_id, profile_id, created_at, modified_at, is_admin, is_owner, can_edit, id) FROM stdin;
d480a671-7255-80d5-8007-e62ea52793a7	d480a671-7255-80d5-8007-e62ea5265396	2026-04-20 16:12:30.759769+00	2026-04-20 16:12:30.759769+00	t	t	t	0d0c7559-67a1-4299-9b94-baff0aa06967
d480a671-7255-80d5-8007-e62ea5466832	d480a671-7255-80d5-8007-e62ea545dcd6	2026-04-20 16:12:30.87529+00	2026-04-20 16:12:30.87529+00	t	t	t	9bb601bb-9dac-4c2a-8109-a5168ed05238
d480a671-7255-80d5-8007-e62ea5610015	d480a671-7255-80d5-8007-e62ea560817c	2026-04-20 16:12:30.982295+00	2026-04-20 16:12:30.982295+00	t	t	t	4149ab7c-9372-4e77-8af4-ecd2d1d946ec
d480a671-7255-80d5-8007-e62ea57cf250	d480a671-7255-80d5-8007-e62ea57c6f76	2026-04-20 16:12:31.093856+00	2026-04-20 16:12:31.093856+00	t	t	t	68b449a2-0ead-4acd-812e-285600d56257
d480a671-7255-80d5-8007-e62ea598e352	d480a671-7255-80d5-8007-e62ea5980177	2026-04-20 16:12:31.206222+00	2026-04-20 16:12:31.206222+00	t	t	t	21f3d730-5247-4c03-90bb-d99a518f345d
d480a671-7255-80d5-8007-e62ea5c0be6b	d480a671-7255-80d5-8007-e62ea5bfccfd	2026-04-20 16:12:31.365203+00	2026-04-20 16:12:31.365203+00	t	t	t	07cd85da-fe45-456a-bab4-134b836922b6
d480a671-7255-80d5-8007-e62ea5dba332	d480a671-7255-80d5-8007-e62ea5db0605	2026-04-20 16:12:31.471405+00	2026-04-20 16:12:31.471405+00	t	t	t	eb20af6a-cb7b-49d4-bae7-09cecceb9272
d480a671-7255-80d5-8007-e62ea5f721e7	d480a671-7255-80d5-8007-e62ea5f69826	2026-04-20 16:12:31.582558+00	2026-04-20 16:12:31.582558+00	t	t	t	92587ede-322a-486d-9b7e-9fdaa8619d88
d480a671-7255-80d5-8007-e62ea614ddc8	d480a671-7255-80d5-8007-e62ea6147c7f	2026-04-20 16:12:31.70109+00	2026-04-20 16:12:31.70109+00	t	t	t	d0cc7f4d-c802-4c4f-b989-a7f527ca8c29
\.


--
-- Data for Name: team_project_profile_rel; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.team_project_profile_rel (team_id, profile_id, project_id, created_at, modified_at, is_pinned, id) FROM stdin;
\.


--
-- Data for Name: usage_quote; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.usage_quote (id, target, quote, profile_id, project_id, team_id, file_id) FROM stdin;
\.


--
-- Data for Name: webhook; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.webhook (id, team_id, created_at, updated_at, uri, mtype, error_code, error_count, is_active, secret_key, profile_id) FROM stdin;
\.


--
-- Data for Name: webhook_delivery; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.webhook_delivery (webhook_id, created_at, error_code, req_data, rsp_data) FROM stdin;
\.


--
-- Name: access_token access_token_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_token
    ADD CONSTRAINT access_token_pkey PRIMARY KEY (id);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: comment comment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comment
    ADD CONSTRAINT comment_pkey PRIMARY KEY (id);


--
-- Name: comment_thread comment_thread_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comment_thread
    ADD CONSTRAINT comment_thread_pkey PRIMARY KEY (id);


--
-- Name: comment_thread_status comment_thread_status_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comment_thread_status
    ADD CONSTRAINT comment_thread_status_pkey PRIMARY KEY (thread_id, profile_id);


--
-- Name: file_change file_change_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_change
    ADD CONSTRAINT file_change_pkey PRIMARY KEY (id);


--
-- Name: file_data file_data_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_data
    ADD CONSTRAINT file_data_pkey PRIMARY KEY (file_id, id);


--
-- Name: file_data_00 file_data_00_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_data_00
    ADD CONSTRAINT file_data_00_pkey PRIMARY KEY (file_id, id);


--
-- Name: file_data_01 file_data_01_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_data_01
    ADD CONSTRAINT file_data_01_pkey PRIMARY KEY (file_id, id);


--
-- Name: file_data_02 file_data_02_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_data_02
    ADD CONSTRAINT file_data_02_pkey PRIMARY KEY (file_id, id);


--
-- Name: file_data_03 file_data_03_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_data_03
    ADD CONSTRAINT file_data_03_pkey PRIMARY KEY (file_id, id);


--
-- Name: file_data_04 file_data_04_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_data_04
    ADD CONSTRAINT file_data_04_pkey PRIMARY KEY (file_id, id);


--
-- Name: file_data_05 file_data_05_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_data_05
    ADD CONSTRAINT file_data_05_pkey PRIMARY KEY (file_id, id);


--
-- Name: file_data_06 file_data_06_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_data_06
    ADD CONSTRAINT file_data_06_pkey PRIMARY KEY (file_id, id);


--
-- Name: file_data_07 file_data_07_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_data_07
    ADD CONSTRAINT file_data_07_pkey PRIMARY KEY (file_id, id);


--
-- Name: file_data_08 file_data_08_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_data_08
    ADD CONSTRAINT file_data_08_pkey PRIMARY KEY (file_id, id);


--
-- Name: file_data_09 file_data_09_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_data_09
    ADD CONSTRAINT file_data_09_pkey PRIMARY KEY (file_id, id);


--
-- Name: file_data_10 file_data_10_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_data_10
    ADD CONSTRAINT file_data_10_pkey PRIMARY KEY (file_id, id);


--
-- Name: file_data_11 file_data_11_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_data_11
    ADD CONSTRAINT file_data_11_pkey PRIMARY KEY (file_id, id);


--
-- Name: file_data_12 file_data_12_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_data_12
    ADD CONSTRAINT file_data_12_pkey PRIMARY KEY (file_id, id);


--
-- Name: file_data_13 file_data_13_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_data_13
    ADD CONSTRAINT file_data_13_pkey PRIMARY KEY (file_id, id);


--
-- Name: file_data_14 file_data_14_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_data_14
    ADD CONSTRAINT file_data_14_pkey PRIMARY KEY (file_id, id);


--
-- Name: file_data_15 file_data_15_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_data_15
    ADD CONSTRAINT file_data_15_pkey PRIMARY KEY (file_id, id);


--
-- Name: file_data_fragment file_data_fragment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_data_fragment
    ADD CONSTRAINT file_data_fragment_pkey PRIMARY KEY (file_id, id);


--
-- Name: file_library_rel file_library_rel_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_library_rel
    ADD CONSTRAINT file_library_rel_pkey PRIMARY KEY (file_id, library_file_id);


--
-- Name: file_media_object file_media_object_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_media_object
    ADD CONSTRAINT file_media_object_pkey PRIMARY KEY (id);


--
-- Name: file_migration file_migration_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_migration
    ADD CONSTRAINT file_migration_pkey PRIMARY KEY (file_id, name);


--
-- Name: file_object_thumbnail file_object_thumbnail_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_object_thumbnail
    ADD CONSTRAINT file_object_thumbnail_pkey PRIMARY KEY (file_id, object_id);


--
-- Name: file file_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file
    ADD CONSTRAINT file_pkey PRIMARY KEY (id);


--
-- Name: file_profile_rel file_profile_rel_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_profile_rel
    ADD CONSTRAINT file_profile_rel_pkey PRIMARY KEY (file_id, profile_id);


--
-- Name: file_tagged_object_thumbnail file_tagged_object_thumbnail_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_tagged_object_thumbnail
    ADD CONSTRAINT file_tagged_object_thumbnail_pkey PRIMARY KEY (file_id, tag, object_id);


--
-- Name: file_thumbnail file_thumbnail_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_thumbnail
    ADD CONSTRAINT file_thumbnail_pkey PRIMARY KEY (file_id, revn);


--
-- Name: global_complaint_report global_complaint_report_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.global_complaint_report
    ADD CONSTRAINT global_complaint_report_pkey PRIMARY KEY (email, created_at);


--
-- Name: http_session http_session_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.http_session
    ADD CONSTRAINT http_session_pkey PRIMARY KEY (id);


--
-- Name: http_session_v2 http_session_v2_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.http_session_v2
    ADD CONSTRAINT http_session_v2_pkey PRIMARY KEY (id);


--
-- Name: migrations migrations_module_step_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT migrations_module_step_key UNIQUE (module, step);


--
-- Name: presence presence_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.presence
    ADD CONSTRAINT presence_pkey PRIMARY KEY (file_id, session_id, profile_id);


--
-- Name: profile_complaint_report profile_complaint_report_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profile_complaint_report
    ADD CONSTRAINT profile_complaint_report_pkey PRIMARY KEY (profile_id, created_at);


--
-- Name: profile profile_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profile
    ADD CONSTRAINT profile_pkey PRIMARY KEY (id);


--
-- Name: project project_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project
    ADD CONSTRAINT project_pkey PRIMARY KEY (id);


--
-- Name: project_profile_rel project_profile_rel_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_profile_rel
    ADD CONSTRAINT project_profile_rel_pkey PRIMARY KEY (id);


--
-- Name: project_profile_rel project_profile_rel_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_profile_rel
    ADD CONSTRAINT project_profile_rel_unique UNIQUE (project_id, profile_id);


--
-- Name: scheduled_task_history scheduled_task_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scheduled_task_history
    ADD CONSTRAINT scheduled_task_history_pkey PRIMARY KEY (id, created_at);


--
-- Name: scheduled_task scheduled_task_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scheduled_task
    ADD CONSTRAINT scheduled_task_pkey PRIMARY KEY (id);


--
-- Name: server_error_report server_error_report_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.server_error_report
    ADD CONSTRAINT server_error_report_pkey PRIMARY KEY (id);


--
-- Name: server_prop server_prop_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.server_prop
    ADD CONSTRAINT server_prop_pkey PRIMARY KEY (id);


--
-- Name: share_link share_link_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.share_link
    ADD CONSTRAINT share_link_pkey PRIMARY KEY (id);


--
-- Name: sso_provider sso_provider_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sso_provider
    ADD CONSTRAINT sso_provider_pkey PRIMARY KEY (id);


--
-- Name: storage_object storage_object_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_object
    ADD CONSTRAINT storage_object_pkey PRIMARY KEY (id);


--
-- Name: task task_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task
    ADD CONSTRAINT task_pkey PRIMARY KEY (id);


--
-- Name: team_access_request team_access_request_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_access_request
    ADD CONSTRAINT team_access_request_pkey PRIMARY KEY (id);


--
-- Name: team_access_request team_access_request_team_id_requester_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_access_request
    ADD CONSTRAINT team_access_request_team_id_requester_id_key UNIQUE (team_id, requester_id);


--
-- Name: team_font_variant team_font_variant_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_font_variant
    ADD CONSTRAINT team_font_variant_pkey PRIMARY KEY (id);


--
-- Name: team_invitation team_invitation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_invitation
    ADD CONSTRAINT team_invitation_pkey PRIMARY KEY (id);


--
-- Name: team_invitation team_invitation_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_invitation
    ADD CONSTRAINT team_invitation_unique UNIQUE (team_id, email_to);


--
-- Name: team team_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team
    ADD CONSTRAINT team_pkey PRIMARY KEY (id);


--
-- Name: team_profile_rel team_profile_rel_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_profile_rel
    ADD CONSTRAINT team_profile_rel_pkey PRIMARY KEY (id);


--
-- Name: team_profile_rel team_profile_rel_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_profile_rel
    ADD CONSTRAINT team_profile_rel_unique UNIQUE (team_id, profile_id);


--
-- Name: team_project_profile_rel team_project_profile_rel_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_project_profile_rel
    ADD CONSTRAINT team_project_profile_rel_pkey PRIMARY KEY (id);


--
-- Name: team_project_profile_rel team_project_profile_rel_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_project_profile_rel
    ADD CONSTRAINT team_project_profile_rel_unique UNIQUE (team_id, project_id, profile_id);


--
-- Name: usage_quote usage_quote_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usage_quote
    ADD CONSTRAINT usage_quote_pkey PRIMARY KEY (id);


--
-- Name: webhook_delivery webhook_delivery_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhook_delivery
    ADD CONSTRAINT webhook_delivery_pkey PRIMARY KEY (webhook_id, created_at);


--
-- Name: webhook webhook_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhook
    ADD CONSTRAINT webhook_pkey PRIMARY KEY (id);


--
-- Name: access_token__profile_id__idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX access_token__profile_id__idx ON public.access_token USING btree (profile_id);


--
-- Name: comment__owner_id__idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX comment__owner_id__idx ON public.comment USING btree (owner_id);


--
-- Name: comment__thread_id__idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX comment__thread_id__idx ON public.comment USING btree (thread_id);


--
-- Name: comment_thread__file_id__seqn__idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX comment_thread__file_id__seqn__idx ON public.comment_thread USING btree (file_id, seqn);


--
-- Name: comment_thread__owner_id__idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX comment_thread__owner_id__idx ON public.comment_thread USING btree (owner_id);


--
-- Name: file__data_ref_id__idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file__data_ref_id__idx ON public.file USING btree (data_ref_id);


--
-- Name: file__deleted_at__idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file__deleted_at__idx ON public.file USING btree (deleted_at, id) WHERE (deleted_at IS NOT NULL);


--
-- Name: file__modified_at__has_media_trimmed__idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file__modified_at__has_media_trimmed__idx ON public.file USING btree (modified_at) WHERE (has_media_trimmed IS FALSE);


--
-- Name: file__modified_at__with__data__idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file__modified_at__with__data__idx ON public.file USING btree (modified_at, id) WHERE (data IS NOT NULL);


--
-- Name: file__project_id__idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file__project_id__idx ON public.file USING btree (project_id);


--
-- Name: file_change__data_ref_id__idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_change__data_ref_id__idx ON public.file_change USING btree (data_ref_id);


--
-- Name: file_change__deleted_at__idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_change__deleted_at__idx ON public.file_change USING btree (deleted_at, id) WHERE (deleted_at IS NOT NULL);


--
-- Name: file_change__file_id__revn__idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_change__file_id__revn__idx ON public.file_change USING btree (file_id, revn);


--
-- Name: file_change__locked_by__idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_change__locked_by__idx ON public.file_change USING btree (locked_by) WHERE (locked_by IS NOT NULL);


--
-- Name: file_change__profile_id__idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_change__profile_id__idx ON public.file_change USING btree (profile_id) WHERE (profile_id IS NOT NULL);


--
-- Name: file_change__system_snapshots__idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_change__system_snapshots__idx ON public.file_change USING btree (file_id, created_at) WHERE ((data IS NOT NULL) AND (created_by = 'system'::text) AND (deleted_at IS NULL));


--
-- Name: file_data__deleted_at__idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_data__deleted_at__idx ON ONLY public.file_data USING btree (deleted_at, file_id, id) WHERE (deleted_at IS NOT NULL);


--
-- Name: file_data_00_deleted_at_file_id_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_data_00_deleted_at_file_id_id_idx ON public.file_data_00 USING btree (deleted_at, file_id, id) WHERE (deleted_at IS NOT NULL);


--
-- Name: file_data_01_deleted_at_file_id_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_data_01_deleted_at_file_id_id_idx ON public.file_data_01 USING btree (deleted_at, file_id, id) WHERE (deleted_at IS NOT NULL);


--
-- Name: file_data_02_deleted_at_file_id_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_data_02_deleted_at_file_id_id_idx ON public.file_data_02 USING btree (deleted_at, file_id, id) WHERE (deleted_at IS NOT NULL);


--
-- Name: file_data_03_deleted_at_file_id_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_data_03_deleted_at_file_id_id_idx ON public.file_data_03 USING btree (deleted_at, file_id, id) WHERE (deleted_at IS NOT NULL);


--
-- Name: file_data_04_deleted_at_file_id_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_data_04_deleted_at_file_id_id_idx ON public.file_data_04 USING btree (deleted_at, file_id, id) WHERE (deleted_at IS NOT NULL);


--
-- Name: file_data_05_deleted_at_file_id_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_data_05_deleted_at_file_id_id_idx ON public.file_data_05 USING btree (deleted_at, file_id, id) WHERE (deleted_at IS NOT NULL);


--
-- Name: file_data_06_deleted_at_file_id_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_data_06_deleted_at_file_id_id_idx ON public.file_data_06 USING btree (deleted_at, file_id, id) WHERE (deleted_at IS NOT NULL);


--
-- Name: file_data_07_deleted_at_file_id_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_data_07_deleted_at_file_id_id_idx ON public.file_data_07 USING btree (deleted_at, file_id, id) WHERE (deleted_at IS NOT NULL);


--
-- Name: file_data_08_deleted_at_file_id_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_data_08_deleted_at_file_id_id_idx ON public.file_data_08 USING btree (deleted_at, file_id, id) WHERE (deleted_at IS NOT NULL);


--
-- Name: file_data_09_deleted_at_file_id_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_data_09_deleted_at_file_id_id_idx ON public.file_data_09 USING btree (deleted_at, file_id, id) WHERE (deleted_at IS NOT NULL);


--
-- Name: file_data_10_deleted_at_file_id_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_data_10_deleted_at_file_id_id_idx ON public.file_data_10 USING btree (deleted_at, file_id, id) WHERE (deleted_at IS NOT NULL);


--
-- Name: file_data_11_deleted_at_file_id_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_data_11_deleted_at_file_id_id_idx ON public.file_data_11 USING btree (deleted_at, file_id, id) WHERE (deleted_at IS NOT NULL);


--
-- Name: file_data_12_deleted_at_file_id_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_data_12_deleted_at_file_id_id_idx ON public.file_data_12 USING btree (deleted_at, file_id, id) WHERE (deleted_at IS NOT NULL);


--
-- Name: file_data_13_deleted_at_file_id_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_data_13_deleted_at_file_id_id_idx ON public.file_data_13 USING btree (deleted_at, file_id, id) WHERE (deleted_at IS NOT NULL);


--
-- Name: file_data_14_deleted_at_file_id_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_data_14_deleted_at_file_id_id_idx ON public.file_data_14 USING btree (deleted_at, file_id, id) WHERE (deleted_at IS NOT NULL);


--
-- Name: file_data_15_deleted_at_file_id_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_data_15_deleted_at_file_id_id_idx ON public.file_data_15 USING btree (deleted_at, file_id, id) WHERE (deleted_at IS NOT NULL);


--
-- Name: file_data_fragment__data_ref_id__idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_data_fragment__data_ref_id__idx ON public.file_data_fragment USING btree (data_ref_id);


--
-- Name: file_data_fragment__deleted_at__idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_data_fragment__deleted_at__idx ON public.file_data_fragment USING btree (deleted_at, file_id, id) WHERE (deleted_at IS NOT NULL);


--
-- Name: file_library_rel__file_id__idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_library_rel__file_id__idx ON public.file_library_rel USING btree (file_id);


--
-- Name: file_library_rel__library_file_id__idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_library_rel__library_file_id__idx ON public.file_library_rel USING btree (library_file_id);


--
-- Name: file_media_object__deleted_at__idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_media_object__deleted_at__idx ON public.file_media_object USING btree (deleted_at, id, media_id) WHERE (deleted_at IS NOT NULL);


--
-- Name: file_media_object__file_id__idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_media_object__file_id__idx ON public.file_media_object USING btree (file_id);


--
-- Name: file_media_object__image_id__idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_media_object__image_id__idx ON public.file_media_object USING btree (media_id);


--
-- Name: file_media_object__thumbnail_id__idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_media_object__thumbnail_id__idx ON public.file_media_object USING btree (thumbnail_id);


--
-- Name: file_profile_rel__file_id__idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_profile_rel__file_id__idx ON public.file_profile_rel USING btree (file_id);


--
-- Name: file_profile_rel__profile_id__idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_profile_rel__profile_id__idx ON public.file_profile_rel USING btree (profile_id);


--
-- Name: file_tagged_object_thumbnail__deleted_at__idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_tagged_object_thumbnail__deleted_at__idx ON public.file_tagged_object_thumbnail USING btree (deleted_at, file_id, object_id, media_id) WHERE (deleted_at IS NOT NULL);


--
-- Name: file_tagged_object_thumbnail__media_id__idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_tagged_object_thumbnail__media_id__idx ON public.file_tagged_object_thumbnail USING btree (media_id);


--
-- Name: file_thumbnail__deleted_at__idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_thumbnail__deleted_at__idx ON public.file_thumbnail USING btree (deleted_at, file_id, revn, media_id) WHERE (deleted_at IS NOT NULL);


--
-- Name: file_thumbnail__media_id__idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_thumbnail__media_id__idx ON public.file_thumbnail USING btree (media_id);


--
-- Name: http_session__updated_at__idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX http_session__updated_at__idx ON public.http_session USING btree (updated_at) WHERE (updated_at IS NOT NULL);


--
-- Name: http_session_v2__profile_id__idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX http_session_v2__profile_id__idx ON public.http_session_v2 USING btree (profile_id);


--
-- Name: http_session_v2__sso_provider_id__idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX http_session_v2__sso_provider_id__idx ON public.http_session_v2 USING btree (sso_provider_id) WHERE (sso_provider_id IS NOT NULL);


--
-- Name: http_session_v2__sso_session_id__idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX http_session_v2__sso_session_id__idx ON public.http_session_v2 USING btree (sso_session_id) WHERE (sso_session_id IS NOT NULL);


--
-- Name: profile__default_project__idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX profile__default_project__idx ON public.profile USING btree (default_project_id);


--
-- Name: profile__default_team__idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX profile__default_team__idx ON public.profile USING btree (default_team_id);


--
-- Name: profile__deleted_at__idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX profile__deleted_at__idx ON public.profile USING btree (deleted_at, id) WHERE (deleted_at IS NOT NULL);


--
-- Name: profile__email__idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX profile__email__idx ON public.profile USING btree (email) WHERE (deleted_at IS NULL);


--
-- Name: profile__is_demo; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX profile__is_demo ON public.profile USING btree (is_demo) WHERE ((deleted_at IS NULL) AND (is_demo IS TRUE));


--
-- Name: profile__photo_id__idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX profile__photo_id__idx ON public.profile USING btree (photo_id);


--
-- Name: profile__props__newsletter1__idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX profile__props__newsletter1__idx ON public.profile USING btree (email) WHERE ((props ->> '~:newsletter-news'::text) = 'true'::text);


--
-- Name: profile__props__newsletter2__idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX profile__props__newsletter2__idx ON public.profile USING btree (email) WHERE ((props ->> '~:newsletter-updates'::text) = 'true'::text);


--
-- Name: project__deleted_at__idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project__deleted_at__idx ON public.project USING btree (deleted_at, id) WHERE (deleted_at IS NOT NULL);


--
-- Name: project__team_id__idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project__team_id__idx ON public.project USING btree (team_id);


--
-- Name: scheduled_task_history__task_id__idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX scheduled_task_history__task_id__idx ON public.scheduled_task_history USING btree (task_id);


--
-- Name: server_error_report__created_at__idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX server_error_report__created_at__idx ON public.server_error_report USING btree (created_at);


--
-- Name: server_error_report__version__idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX server_error_report__version__idx ON public.server_error_report USING btree (version);


--
-- Name: share_link_file_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX share_link_file_id_idx ON public.share_link USING btree (file_id);


--
-- Name: share_link_owner_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX share_link_owner_id_idx ON public.share_link USING btree (owner_id);


--
-- Name: sso_provider__domain__idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX sso_provider__domain__idx ON public.sso_provider USING btree (domain);


--
-- Name: storage_object__hash_backend_bucket__idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX storage_object__hash_backend_bucket__idx ON public.storage_object USING btree (((metadata ->> '~:hash'::text)), ((metadata ->> '~:bucket'::text)), backend) WHERE (deleted_at IS NULL);


--
-- Name: storage_object__id__deleted_at__idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX storage_object__id__deleted_at__idx ON public.storage_object USING btree (deleted_at, id) WHERE (deleted_at IS NOT NULL);


--
-- Name: storage_object__id_touched_at__idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX storage_object__id_touched_at__idx ON public.storage_object USING btree (touched_at, id) WHERE (touched_at IS NOT NULL);


--
-- Name: task__label_name_queue__idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX task__label_name_queue__idx ON public.task USING btree (label, name, queue) WHERE (status = 'new'::text);


--
-- Name: task__scheduled_at_queue__idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX task__scheduled_at_queue__idx ON public.task USING btree (scheduled_at, queue) WHERE ((status = 'new'::text) OR (status = 'retry'::text));


--
-- Name: team__deleted_at__idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX team__deleted_at__idx ON public.team USING btree (deleted_at, id) WHERE (deleted_at IS NOT NULL);


--
-- Name: team__photo_id__idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX team__photo_id__idx ON public.team USING btree (photo_id);


--
-- Name: team_font_variant__deleted_at__idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX team_font_variant__deleted_at__idx ON public.team_font_variant USING btree (deleted_at, id) WHERE (deleted_at IS NOT NULL);


--
-- Name: team_font_variant_otf_file_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX team_font_variant_otf_file_id_idx ON public.team_font_variant USING btree (otf_file_id);


--
-- Name: team_font_variant_profile_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX team_font_variant_profile_id_idx ON public.team_font_variant USING btree (profile_id);


--
-- Name: team_font_variant_team_id_font_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX team_font_variant_team_id_font_id_idx ON public.team_font_variant USING btree (team_id, font_id);


--
-- Name: team_font_variant_ttf_file_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX team_font_variant_ttf_file_id_idx ON public.team_font_variant USING btree (ttf_file_id);


--
-- Name: team_font_variant_woff1_file_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX team_font_variant_woff1_file_id_idx ON public.team_font_variant USING btree (woff1_file_id);


--
-- Name: team_font_variant_woff2_file_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX team_font_variant_woff2_file_id_idx ON public.team_font_variant USING btree (woff2_file_id);


--
-- Name: usage_quote__profile_id__idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX usage_quote__profile_id__idx ON public.usage_quote USING btree (profile_id, target);


--
-- Name: usage_quote__project_id__idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX usage_quote__project_id__idx ON public.usage_quote USING btree (project_id, target);


--
-- Name: usage_quote__team_id__idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX usage_quote__team_id__idx ON public.usage_quote USING btree (team_id, target);


--
-- Name: webhook__profile_id__idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX webhook__profile_id__idx ON public.webhook USING btree (profile_id) WHERE (profile_id IS NOT NULL);


--
-- Name: webhook__team_id__idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX webhook__team_id__idx ON public.webhook USING btree (team_id);


--
-- Name: file_data_00_deleted_at_file_id_id_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.file_data__deleted_at__idx ATTACH PARTITION public.file_data_00_deleted_at_file_id_id_idx;


--
-- Name: file_data_00_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.file_data_pkey ATTACH PARTITION public.file_data_00_pkey;


--
-- Name: file_data_01_deleted_at_file_id_id_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.file_data__deleted_at__idx ATTACH PARTITION public.file_data_01_deleted_at_file_id_id_idx;


--
-- Name: file_data_01_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.file_data_pkey ATTACH PARTITION public.file_data_01_pkey;


--
-- Name: file_data_02_deleted_at_file_id_id_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.file_data__deleted_at__idx ATTACH PARTITION public.file_data_02_deleted_at_file_id_id_idx;


--
-- Name: file_data_02_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.file_data_pkey ATTACH PARTITION public.file_data_02_pkey;


--
-- Name: file_data_03_deleted_at_file_id_id_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.file_data__deleted_at__idx ATTACH PARTITION public.file_data_03_deleted_at_file_id_id_idx;


--
-- Name: file_data_03_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.file_data_pkey ATTACH PARTITION public.file_data_03_pkey;


--
-- Name: file_data_04_deleted_at_file_id_id_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.file_data__deleted_at__idx ATTACH PARTITION public.file_data_04_deleted_at_file_id_id_idx;


--
-- Name: file_data_04_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.file_data_pkey ATTACH PARTITION public.file_data_04_pkey;


--
-- Name: file_data_05_deleted_at_file_id_id_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.file_data__deleted_at__idx ATTACH PARTITION public.file_data_05_deleted_at_file_id_id_idx;


--
-- Name: file_data_05_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.file_data_pkey ATTACH PARTITION public.file_data_05_pkey;


--
-- Name: file_data_06_deleted_at_file_id_id_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.file_data__deleted_at__idx ATTACH PARTITION public.file_data_06_deleted_at_file_id_id_idx;


--
-- Name: file_data_06_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.file_data_pkey ATTACH PARTITION public.file_data_06_pkey;


--
-- Name: file_data_07_deleted_at_file_id_id_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.file_data__deleted_at__idx ATTACH PARTITION public.file_data_07_deleted_at_file_id_id_idx;


--
-- Name: file_data_07_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.file_data_pkey ATTACH PARTITION public.file_data_07_pkey;


--
-- Name: file_data_08_deleted_at_file_id_id_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.file_data__deleted_at__idx ATTACH PARTITION public.file_data_08_deleted_at_file_id_id_idx;


--
-- Name: file_data_08_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.file_data_pkey ATTACH PARTITION public.file_data_08_pkey;


--
-- Name: file_data_09_deleted_at_file_id_id_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.file_data__deleted_at__idx ATTACH PARTITION public.file_data_09_deleted_at_file_id_id_idx;


--
-- Name: file_data_09_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.file_data_pkey ATTACH PARTITION public.file_data_09_pkey;


--
-- Name: file_data_10_deleted_at_file_id_id_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.file_data__deleted_at__idx ATTACH PARTITION public.file_data_10_deleted_at_file_id_id_idx;


--
-- Name: file_data_10_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.file_data_pkey ATTACH PARTITION public.file_data_10_pkey;


--
-- Name: file_data_11_deleted_at_file_id_id_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.file_data__deleted_at__idx ATTACH PARTITION public.file_data_11_deleted_at_file_id_id_idx;


--
-- Name: file_data_11_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.file_data_pkey ATTACH PARTITION public.file_data_11_pkey;


--
-- Name: file_data_12_deleted_at_file_id_id_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.file_data__deleted_at__idx ATTACH PARTITION public.file_data_12_deleted_at_file_id_id_idx;


--
-- Name: file_data_12_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.file_data_pkey ATTACH PARTITION public.file_data_12_pkey;


--
-- Name: file_data_13_deleted_at_file_id_id_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.file_data__deleted_at__idx ATTACH PARTITION public.file_data_13_deleted_at_file_id_id_idx;


--
-- Name: file_data_13_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.file_data_pkey ATTACH PARTITION public.file_data_13_pkey;


--
-- Name: file_data_14_deleted_at_file_id_id_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.file_data__deleted_at__idx ATTACH PARTITION public.file_data_14_deleted_at_file_id_id_idx;


--
-- Name: file_data_14_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.file_data_pkey ATTACH PARTITION public.file_data_14_pkey;


--
-- Name: file_data_15_deleted_at_file_id_id_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.file_data__deleted_at__idx ATTACH PARTITION public.file_data_15_deleted_at_file_id_id_idx;


--
-- Name: file_data_15_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.file_data_pkey ATTACH PARTITION public.file_data_15_pkey;


--
-- Name: file_media_object deletion_protection__tgr; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER deletion_protection__tgr BEFORE DELETE ON public.file_media_object FOR EACH STATEMENT WHEN (((current_setting('rules.deletion_protection'::text, true) = ANY (ARRAY['on'::text, ''::text])) OR (current_setting('rules.deletion_protection'::text, true) IS NULL))) EXECUTE FUNCTION public.raise_deletion_protection();


--
-- Name: file_tagged_object_thumbnail deletion_protection__tgr; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER deletion_protection__tgr BEFORE DELETE ON public.file_tagged_object_thumbnail FOR EACH STATEMENT WHEN (((current_setting('rules.deletion_protection'::text, true) = ANY (ARRAY['on'::text, ''::text])) OR (current_setting('rules.deletion_protection'::text, true) IS NULL))) EXECUTE FUNCTION public.raise_deletion_protection();


--
-- Name: file_thumbnail deletion_protection__tgr; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER deletion_protection__tgr BEFORE DELETE ON public.file_thumbnail FOR EACH STATEMENT WHEN (((current_setting('rules.deletion_protection'::text, true) = ANY (ARRAY['on'::text, ''::text])) OR (current_setting('rules.deletion_protection'::text, true) IS NULL))) EXECUTE FUNCTION public.raise_deletion_protection();


--
-- Name: profile deletion_protection__tgr; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER deletion_protection__tgr BEFORE DELETE ON public.profile FOR EACH STATEMENT WHEN (((current_setting('rules.deletion_protection'::text, true) = ANY (ARRAY['on'::text, ''::text])) OR (current_setting('rules.deletion_protection'::text, true) IS NULL))) EXECUTE FUNCTION public.raise_deletion_protection();


--
-- Name: team deletion_protection__tgr; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER deletion_protection__tgr BEFORE DELETE ON public.team FOR EACH STATEMENT WHEN (((current_setting('rules.deletion_protection'::text, true) = ANY (ARRAY['on'::text, ''::text])) OR (current_setting('rules.deletion_protection'::text, true) IS NULL))) EXECUTE FUNCTION public.raise_deletion_protection();


--
-- Name: team_font_variant deletion_protection__tgr; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER deletion_protection__tgr BEFORE DELETE ON public.team_font_variant FOR EACH STATEMENT WHEN (((current_setting('rules.deletion_protection'::text, true) = ANY (ARRAY['on'::text, ''::text])) OR (current_setting('rules.deletion_protection'::text, true) IS NULL))) EXECUTE FUNCTION public.raise_deletion_protection();


--
-- Name: access_token access_token_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_token
    ADD CONSTRAINT access_token_profile_id_fkey FOREIGN KEY (profile_id) REFERENCES public.profile(id) ON DELETE CASCADE DEFERRABLE;


--
-- Name: comment comment_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comment
    ADD CONSTRAINT comment_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.profile(id) ON DELETE CASCADE;


--
-- Name: comment_thread comment_thread_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comment_thread
    ADD CONSTRAINT comment_thread_file_id_fkey FOREIGN KEY (file_id) REFERENCES public.file(id) ON DELETE CASCADE;


--
-- Name: comment comment_thread_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comment
    ADD CONSTRAINT comment_thread_id_fkey FOREIGN KEY (thread_id) REFERENCES public.comment_thread(id) ON DELETE CASCADE;


--
-- Name: comment_thread comment_thread_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comment_thread
    ADD CONSTRAINT comment_thread_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.profile(id) ON DELETE CASCADE;


--
-- Name: comment_thread_status comment_thread_status_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comment_thread_status
    ADD CONSTRAINT comment_thread_status_profile_id_fkey FOREIGN KEY (profile_id) REFERENCES public.profile(id) ON DELETE CASCADE;


--
-- Name: comment_thread_status comment_thread_status_thread_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comment_thread_status
    ADD CONSTRAINT comment_thread_status_thread_id_fkey FOREIGN KEY (thread_id) REFERENCES public.comment_thread(id) ON DELETE CASCADE;


--
-- Name: file_change file_change_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_change
    ADD CONSTRAINT file_change_file_id_fkey FOREIGN KEY (file_id) REFERENCES public.file(id) DEFERRABLE;


--
-- Name: file_change file_change_locked_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_change
    ADD CONSTRAINT file_change_locked_by_fkey FOREIGN KEY (locked_by) REFERENCES public.profile(id) ON DELETE SET NULL DEFERRABLE;


--
-- Name: file_change file_change_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_change
    ADD CONSTRAINT file_change_profile_id_fkey FOREIGN KEY (profile_id) REFERENCES public.profile(id) ON DELETE SET NULL DEFERRABLE;


--
-- Name: file_data file_data_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE public.file_data
    ADD CONSTRAINT file_data_file_id_fkey FOREIGN KEY (file_id) REFERENCES public.file(id) DEFERRABLE;


--
-- Name: file_data_fragment file_data_fragment_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_data_fragment
    ADD CONSTRAINT file_data_fragment_file_id_fkey FOREIGN KEY (file_id) REFERENCES public.file(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- Name: file_library_rel file_library_rel_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_library_rel
    ADD CONSTRAINT file_library_rel_file_id_fkey FOREIGN KEY (file_id) REFERENCES public.file(id) ON DELETE CASCADE DEFERRABLE;


--
-- Name: file_library_rel file_library_rel_library_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_library_rel
    ADD CONSTRAINT file_library_rel_library_file_id_fkey FOREIGN KEY (library_file_id) REFERENCES public.file(id) ON DELETE CASCADE DEFERRABLE;


--
-- Name: file_media_object file_media_object_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_media_object
    ADD CONSTRAINT file_media_object_file_id_fkey FOREIGN KEY (file_id) REFERENCES public.file(id) DEFERRABLE;


--
-- Name: file_media_object file_media_object_media_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_media_object
    ADD CONSTRAINT file_media_object_media_id_fkey FOREIGN KEY (media_id) REFERENCES public.storage_object(id) DEFERRABLE;


--
-- Name: file_media_object file_media_object_thumbnail_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_media_object
    ADD CONSTRAINT file_media_object_thumbnail_id_fkey FOREIGN KEY (thumbnail_id) REFERENCES public.storage_object(id) DEFERRABLE;


--
-- Name: file_migration file_migration_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_migration
    ADD CONSTRAINT file_migration_file_id_fkey FOREIGN KEY (file_id) REFERENCES public.file(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- Name: file_object_thumbnail file_object_thumbnail_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_object_thumbnail
    ADD CONSTRAINT file_object_thumbnail_file_id_fkey FOREIGN KEY (file_id) REFERENCES public.file(id) DEFERRABLE;


--
-- Name: file_object_thumbnail file_object_thumbnail_media_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_object_thumbnail
    ADD CONSTRAINT file_object_thumbnail_media_id_fkey FOREIGN KEY (media_id) REFERENCES public.storage_object(id) DEFERRABLE;


--
-- Name: file_profile_rel file_profile_rel_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_profile_rel
    ADD CONSTRAINT file_profile_rel_file_id_fkey FOREIGN KEY (file_id) REFERENCES public.file(id) ON DELETE CASCADE;


--
-- Name: file_profile_rel file_profile_rel_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_profile_rel
    ADD CONSTRAINT file_profile_rel_profile_id_fkey FOREIGN KEY (profile_id) REFERENCES public.profile(id) ON DELETE CASCADE;


--
-- Name: file file_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file
    ADD CONSTRAINT file_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.project(id) DEFERRABLE;


--
-- Name: file_tagged_object_thumbnail file_tagged_object_thumbnail_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_tagged_object_thumbnail
    ADD CONSTRAINT file_tagged_object_thumbnail_file_id_fkey FOREIGN KEY (file_id) REFERENCES public.file(id) DEFERRABLE;


--
-- Name: file_tagged_object_thumbnail file_tagged_object_thumbnail_media_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_tagged_object_thumbnail
    ADD CONSTRAINT file_tagged_object_thumbnail_media_id_fkey FOREIGN KEY (media_id) REFERENCES public.storage_object(id) DEFERRABLE;


--
-- Name: file_thumbnail file_thumbnail_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_thumbnail
    ADD CONSTRAINT file_thumbnail_file_id_fkey FOREIGN KEY (file_id) REFERENCES public.file(id) DEFERRABLE;


--
-- Name: file_thumbnail file_thumbnail_media_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_thumbnail
    ADD CONSTRAINT file_thumbnail_media_id_fkey FOREIGN KEY (media_id) REFERENCES public.storage_object(id) DEFERRABLE;


--
-- Name: http_session http_session_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.http_session
    ADD CONSTRAINT http_session_profile_id_fkey FOREIGN KEY (profile_id) REFERENCES public.profile(id) ON DELETE CASCADE;


--
-- Name: http_session_v2 http_session_v2_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.http_session_v2
    ADD CONSTRAINT http_session_v2_profile_id_fkey FOREIGN KEY (profile_id) REFERENCES public.profile(id) ON DELETE CASCADE;


--
-- Name: http_session_v2 http_session_v2_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.http_session_v2
    ADD CONSTRAINT http_session_v2_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES public.sso_provider(id) ON DELETE CASCADE;


--
-- Name: presence presence_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.presence
    ADD CONSTRAINT presence_file_id_fkey FOREIGN KEY (file_id) REFERENCES public.file(id) ON DELETE CASCADE;


--
-- Name: presence presence_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.presence
    ADD CONSTRAINT presence_profile_id_fkey FOREIGN KEY (profile_id) REFERENCES public.profile(id) ON DELETE CASCADE;


--
-- Name: profile_complaint_report profile_complaint_report_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profile_complaint_report
    ADD CONSTRAINT profile_complaint_report_profile_id_fkey FOREIGN KEY (profile_id) REFERENCES public.profile(id) ON DELETE CASCADE;


--
-- Name: profile profile_default_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profile
    ADD CONSTRAINT profile_default_project_id_fkey FOREIGN KEY (default_project_id) REFERENCES public.project(id) DEFERRABLE;


--
-- Name: profile profile_default_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profile
    ADD CONSTRAINT profile_default_team_id_fkey FOREIGN KEY (default_team_id) REFERENCES public.team(id) DEFERRABLE;


--
-- Name: profile profile_photo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profile
    ADD CONSTRAINT profile_photo_id_fkey FOREIGN KEY (photo_id) REFERENCES public.storage_object(id) DEFERRABLE;


--
-- Name: project_profile_rel project_profile_rel_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_profile_rel
    ADD CONSTRAINT project_profile_rel_profile_id_fkey FOREIGN KEY (profile_id) REFERENCES public.profile(id) ON DELETE CASCADE;


--
-- Name: project_profile_rel project_profile_rel_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_profile_rel
    ADD CONSTRAINT project_profile_rel_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.project(id) ON DELETE CASCADE;


--
-- Name: project project_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project
    ADD CONSTRAINT project_team_id_fkey FOREIGN KEY (team_id) REFERENCES public.team(id) DEFERRABLE;


--
-- Name: scheduled_task_history scheduled_task_history_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scheduled_task_history
    ADD CONSTRAINT scheduled_task_history_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.scheduled_task(id);


--
-- Name: share_link share_link_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.share_link
    ADD CONSTRAINT share_link_file_id_fkey FOREIGN KEY (file_id) REFERENCES public.file(id) ON DELETE CASCADE DEFERRABLE;


--
-- Name: share_link share_link_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.share_link
    ADD CONSTRAINT share_link_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.profile(id) ON DELETE SET NULL DEFERRABLE;


--
-- Name: team_access_request team_access_request_requester_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_access_request
    ADD CONSTRAINT team_access_request_requester_id_fkey FOREIGN KEY (requester_id) REFERENCES public.profile(id) ON DELETE CASCADE DEFERRABLE;


--
-- Name: team_access_request team_access_request_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_access_request
    ADD CONSTRAINT team_access_request_team_id_fkey FOREIGN KEY (team_id) REFERENCES public.team(id) ON DELETE CASCADE DEFERRABLE;


--
-- Name: team_font_variant team_font_variant_otf_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_font_variant
    ADD CONSTRAINT team_font_variant_otf_file_id_fkey FOREIGN KEY (otf_file_id) REFERENCES public.storage_object(id) DEFERRABLE;


--
-- Name: team_font_variant team_font_variant_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_font_variant
    ADD CONSTRAINT team_font_variant_profile_id_fkey FOREIGN KEY (profile_id) REFERENCES public.profile(id) ON DELETE SET NULL DEFERRABLE;


--
-- Name: team_font_variant team_font_variant_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_font_variant
    ADD CONSTRAINT team_font_variant_team_id_fkey FOREIGN KEY (team_id) REFERENCES public.team(id) DEFERRABLE;


--
-- Name: team_font_variant team_font_variant_ttf_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_font_variant
    ADD CONSTRAINT team_font_variant_ttf_file_id_fkey FOREIGN KEY (ttf_file_id) REFERENCES public.storage_object(id) DEFERRABLE;


--
-- Name: team_font_variant team_font_variant_woff1_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_font_variant
    ADD CONSTRAINT team_font_variant_woff1_file_id_fkey FOREIGN KEY (woff1_file_id) REFERENCES public.storage_object(id) DEFERRABLE;


--
-- Name: team_font_variant team_font_variant_woff2_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_font_variant
    ADD CONSTRAINT team_font_variant_woff2_file_id_fkey FOREIGN KEY (woff2_file_id) REFERENCES public.storage_object(id) DEFERRABLE;


--
-- Name: team_invitation team_invitation_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_invitation
    ADD CONSTRAINT team_invitation_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.profile(id) ON DELETE SET NULL;


--
-- Name: team_invitation team_invitation_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_invitation
    ADD CONSTRAINT team_invitation_team_id_fkey FOREIGN KEY (team_id) REFERENCES public.team(id) ON DELETE CASCADE;


--
-- Name: team team_photo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team
    ADD CONSTRAINT team_photo_id_fkey FOREIGN KEY (photo_id) REFERENCES public.storage_object(id) DEFERRABLE;


--
-- Name: team_profile_rel team_profile_rel_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_profile_rel
    ADD CONSTRAINT team_profile_rel_profile_id_fkey FOREIGN KEY (profile_id) REFERENCES public.profile(id) ON DELETE CASCADE;


--
-- Name: team_profile_rel team_profile_rel_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_profile_rel
    ADD CONSTRAINT team_profile_rel_team_id_fkey FOREIGN KEY (team_id) REFERENCES public.team(id) ON DELETE CASCADE;


--
-- Name: team_project_profile_rel team_project_profile_rel_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_project_profile_rel
    ADD CONSTRAINT team_project_profile_rel_profile_id_fkey FOREIGN KEY (profile_id) REFERENCES public.profile(id) ON DELETE CASCADE;


--
-- Name: team_project_profile_rel team_project_profile_rel_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_project_profile_rel
    ADD CONSTRAINT team_project_profile_rel_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.project(id) ON DELETE CASCADE;


--
-- Name: team_project_profile_rel team_project_profile_rel_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_project_profile_rel
    ADD CONSTRAINT team_project_profile_rel_team_id_fkey FOREIGN KEY (team_id) REFERENCES public.team(id) ON DELETE CASCADE;


--
-- Name: usage_quote usage_quote_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usage_quote
    ADD CONSTRAINT usage_quote_file_id_fkey FOREIGN KEY (file_id) REFERENCES public.file(id) ON DELETE CASCADE DEFERRABLE;


--
-- Name: usage_quote usage_quote_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usage_quote
    ADD CONSTRAINT usage_quote_profile_id_fkey FOREIGN KEY (profile_id) REFERENCES public.profile(id) ON DELETE CASCADE DEFERRABLE;


--
-- Name: usage_quote usage_quote_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usage_quote
    ADD CONSTRAINT usage_quote_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.project(id) ON DELETE CASCADE DEFERRABLE;


--
-- Name: usage_quote usage_quote_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usage_quote
    ADD CONSTRAINT usage_quote_team_id_fkey FOREIGN KEY (team_id) REFERENCES public.team(id) ON DELETE CASCADE DEFERRABLE;


--
-- Name: webhook_delivery webhook_delivery_webhook_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhook_delivery
    ADD CONSTRAINT webhook_delivery_webhook_id_fkey FOREIGN KEY (webhook_id) REFERENCES public.webhook(id) ON DELETE CASCADE DEFERRABLE;


--
-- Name: webhook webhook_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhook
    ADD CONSTRAINT webhook_profile_id_fkey FOREIGN KEY (profile_id) REFERENCES public.profile(id) ON DELETE SET NULL;


--
-- Name: webhook webhook_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhook
    ADD CONSTRAINT webhook_team_id_fkey FOREIGN KEY (team_id) REFERENCES public.team(id) ON DELETE CASCADE DEFERRABLE;


--
-- PostgreSQL database dump complete
--

\unrestrict nyTtfaANlX8dGoc1uB4vyXefRnsaDfiThdN4S8aNHFJpNKbU4h1a1hikgxRBjBh

